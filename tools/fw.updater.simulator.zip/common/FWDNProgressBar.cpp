#include "FWDNProgressBar.h"
#include "FWDNUtil.h"

#ifdef WINDOWS
#include <direct.h>
#else
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#endif

clock_t GetClock()
{
#ifdef WINDOWS
	return clock();
#else
	struct timespec cur;
	clock_gettime(CLOCK_MONOTONIC, &cur);
	clock_t ret;
	ret = cur.tv_nsec / 1000000;	//ms
	ret += cur.tv_sec * 1000;	//sec
	return ret;
#endif
}

ProgressBar* ProgressBar::m_pProgressBar = NULL;

ProgressBar* ProgressBar::GetIns(){
    if (m_pProgressBar == NULL) {
      m_pProgressBar = new ProgressBar;
    }
    return m_pProgressBar;
}

ProgressBar::ProgressBar():
m_ullTotal(0),
m_ullCurrent(0),
m_bPrint(false),
m_bStart(false),
m_bShowSpeed(false)
{
	m_startTime = GetClock();
}

ProgressBar::~ProgressBar()
{
}

bool ProgressBar::Plus(unsigned long long ull)
{
	m_ullCurrent += ull;

	if(m_ullCurrent > m_ullTotal) {
		FWDNMessage(FWDN_RED_MSG,
			"ullCurrent(%llu) is greater than ullTotal(%llu)\n",
			m_ullCurrent, m_ullTotal);
		return false;
	} else {
		PrintProgress(GetPercent(m_ullCurrent, m_ullTotal));
	}

	return true;
}

unsigned long long ProgressBar::GetPercent(unsigned long long ull, unsigned long long ullTotal)
{
	if(ullTotal == 0) {
		FWDNMessage(FWDN_RED_MSG, "ullTotal(%llu) is invalid value\n", ullTotal);
		return 0;
	}
	return (unsigned long long)((ull * 100ULL) / ullTotal);
}

void ProgressBar::PrintProgress(unsigned long long ull)
{
	double percentage = (double)ull / (double)100;
    int val = (int) (percentage * 100);
    int lpad = (int) (percentage * PROGRESS_BAR_SIZE);
    int rpad = PROGRESS_BAR_SIZE - lpad;

	if(m_bShowSpeed) {
		clock_t elapsedTime = GetClock() - m_startTime;
		if(elapsedTime == 0) {
			elapsedTime = 1;
		}
		double dMBytePerMsec = (double)m_ullCurrent / (double)elapsedTime;
		double dKBytePerSec = dMBytePerMsec;

		PrintProg("\r%3d%% [%.*s%*s] %lld/%lld %.1lf KB/s",
			val, lpad, PROGRESS_BAR_STR, rpad, "", m_ullCurrent, m_ullTotal, dKBytePerSec);
	} else {
		PrintProg("\r%3d%% [%.*s%*s] %lld/%lld",
			val, lpad, PROGRESS_BAR_STR, rpad, "", m_ullCurrent, m_ullTotal);
	}

	m_bPrint = true;
	m_bStart = true;
}

void ProgressBar::SetTotalSize(unsigned long long ullTotal)
{
	m_ullCurrent = 0;
	m_ullTotal = ullTotal;
	m_startTime = GetClock();
}

void ProgressBar::EraseProgressBar()
{
	EraseLine();
	m_bPrint = true;
}