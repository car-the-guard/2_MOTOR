#pragma once

#ifdef __FUNCTION__
#define WINDOWS
#else
#define LINUX
#endif