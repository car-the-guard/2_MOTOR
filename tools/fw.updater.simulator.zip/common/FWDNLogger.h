#pragma once

#include "config.h"
#ifdef WINDOWS
#include <windows.h>
#endif

#include "FWDNProgressBar.h"
#include <ctime>
#include <cstdio>
#include <string>

#define LOG_FOLDER	"log"

#define FWDN_RED_MSG		1
#define FWDN_GREEN_MSG		2
#define FWDN_BLUE_MSG		3
#define FWDN_PROG_MSG		4	//no function name, line
#define FWDN_WHITE_MSG		5
#define FWDN_DEBUG_MSG		6

#define FWDN_MICOM_NORMAL_MSG	7
#define FWDN_MICOM_ERROR_MSG	8

#define FWDN_DRAM_TOOL_MSG	9

class FWDNLogger {
private:	//singleton
	FWDNLogger();
	static FWDNLogger* m_pFWDNLogger;
public:
    static FWDNLogger* GetIns();

	~FWDNLogger();

	clock_t GetClock();
private:
	bool m_bDebug;
	bool m_bSaveLogFile;
	bool m_bTimeStamp;
	FILE* m_pLogFile;
	clock_t m_startTime;
	char m_strElapsedTime[14];	//14 = [00-00-00-00](13) + '\0'(1)
	char m_strlogFilename[34];	//34 = LOG_FOLDER(4) + FWDN_V8_LOG_00-00-00-00-00-00(29) + '\0'(1)

	//Printing
public:
	void Message(unsigned int uiMsgType, const char *fmt, ...);
	void DebugMessage(unsigned int uiMsgType, const char *fmt, ...);
	void PrintElapsedTime(unsigned int uiMsgType);

	void PrintCurTime();

	//Setting
public:
	void SetSaveLog(bool bSaveLog);
	void TimeStamp(bool bTimeStamp) {m_bTimeStamp = bTimeStamp;}
	void DebugMode(bool bDebug) {m_bDebug = bDebug;}
	bool DebugMode() {return m_bDebug;}

	//Making
private:
	void GetCurTimeStr(std::string *pStrTime);
	void MakeStrElapsedTime();
	void MakeLogFileName();
	void MakeFolder(const char* pFolderNmae);
};

#ifdef WINDOWS
#define FWDNMessage(msgType, format, ...) \
do { \
	if(ProgressBar::GetIns()->IsPrint()) { \
		ProgressBar::GetIns()->EraseProgressBar(); \
	} \
	HANDLE h_console = GetStdHandle(STD_OUTPUT_HANDLE); \
\
	if(msgType == FWDN_RED_MSG) { \
		SetConsoleTextAttribute(h_console, 0xc); \
	} else if(msgType == FWDN_GREEN_MSG) { \
		SetConsoleTextAttribute(h_console, 0xa); \
	} else if(msgType == FWDN_BLUE_MSG) { \
		SetConsoleTextAttribute(h_console, 0x9); \
	} else if(msgType == FWDN_MICOM_ERROR_MSG) { \
		SetConsoleTextAttribute(h_console, 0x5); \
	} else if(msgType == FWDN_MICOM_NORMAL_MSG) { \
		SetConsoleTextAttribute(h_console, 0x3); \
	} else { \
		SetConsoleTextAttribute(h_console, 0x07); \
	} \
\
	FWDNLogger::GetIns()->PrintElapsedTime(msgType); \
	if(msgType != FWDN_DRAM_TOOL_MSG) { \
		FWDNLogger::GetIns()->Message(msgType, "["__FUNCTION__":%d] ", __LINE__); \
	} \
	FWDNLogger::GetIns()->Message(msgType, format, ##__VA_ARGS__); \
\
	SetConsoleTextAttribute(h_console, 0x07); \
\
	if(ProgressBar::GetIns()->IsStart()) { \
		ProgressBar::GetIns()->Plus(0); \
	} \
} while (0)
#else //LINUX
#define FWDNMessage(msgType, format, ...) \
do {\
	if(ProgressBar::GetIns()->IsPrint()) { \
		ProgressBar::GetIns()->EraseProgressBar(); \
	} \
	if(msgType == FWDN_RED_MSG) { \
		printf("\033[31m"); \
	} else if(msgType == FWDN_GREEN_MSG) { \
		printf("\033[32m"); \
	} else if(msgType == FWDN_BLUE_MSG) { \
		printf("\033[34m"); \
	} else if(msgType == FWDN_MICOM_ERROR_MSG) { \
		printf("\033[35m"); \
	} else if(msgType == FWDN_MICOM_NORMAL_MSG) { \
		printf("\033[36m"); \
	} else { \
		printf("\033[0m"); \
	} \
\
	FWDNLogger::GetIns()->PrintElapsedTime(msgType); \
	if(msgType != FWDN_DRAM_TOOL_MSG) { \
		FWDNLogger::GetIns()->Message(msgType, "["); \
		FWDNLogger::GetIns()->Message(msgType, __func__); \
		FWDNLogger::GetIns()->Message(msgType, ":%d] ", __LINE__); \
	} \
	FWDNLogger::GetIns()->Message(msgType, format, ##__VA_ARGS__); \
\
	printf("\033[0m"); \
\
	if(ProgressBar::GetIns()->IsStart()) { \
		ProgressBar::GetIns()->Plus(0); \
	} \
} while(0)
#endif


#ifdef WINDOWS
#define PrintProg(format, ...) \
do { \
	HANDLE h_console = GetStdHandle(STD_OUTPUT_HANDLE); \
	SetConsoleTextAttribute(h_console, 0x2f); \
	printf(format, ##__VA_ARGS__); \
	SetConsoleTextAttribute(h_console, 0x07); \
} while (0)
#else //LINUX
#define PrintProg(format, ...) \
do {\
	printf("\033[42;37m"); \
	printf(format, ##__VA_ARGS__); \
	printf("\033[0m"); \
} while(0)
#endif

#define DEBUG_FWDNMessage(msgType, format, ...) \
do {\
	if(FWDNLogger::GetIns()->DebugMode() == true) { \
		FWDNMessage(msgType, format, ##__VA_ARGS__); \
	} \
} while(0)
