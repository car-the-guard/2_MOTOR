#pragma once

#include <cstring>
#include <cstdlib>

class FWDNVersion {
private:
	FWDNVersion();
	static FWDNVersion* m_pFWDNVersion;

public:
	static FWDNVersion* GetIns();

	void FWVersion(unsigned int version);
	unsigned int FWVersion();

	void HostVersion(unsigned int version);
	unsigned int HostVersion();

	char* StrHostVersion();
	char* StrFWVersion();
	char* StrBuildDate();

private:
	void GetBuildDate();
	void VersionUintToStr(char* str, unsigned int uint);

private:
	static const int VersionMaxLength = 20;
	static const int BuildDateMaxLength = 11;

private:
	char m_strHostVersion[VersionMaxLength];
	char m_strFWVersion[VersionMaxLength];
	unsigned int m_uiHostVersion;
	unsigned int m_uiFWVersion;
	char m_strBuildDate[BuildDateMaxLength];	//xxxx-xx-xx (year-month-day)
	unsigned int m_uiYear;
	unsigned int m_uiMonth;
	unsigned int m_uiDay;
};