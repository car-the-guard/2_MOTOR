#include "FWDNFile.h"

FWDNFile::FWDNFile(const char* pFileName, const char* pMode, unsigned int uiBufSize) :
m_pFile(NULL),
m_pBuffer(NULL),
m_pFileName(NULL),
m_ullFileSize(0)
{
	if(pFileName != NULL) {
		Open(pFileName, pMode);
	}
}

FWDNFile::~FWDNFile()
{
	Clear();
}

bool FWDNFile::Open(const char* pFileName, const char* pMode, unsigned int uiBufSize)
{
	DEBUG_FWDNMessage(FWDN_WHITE_MSG, "Open file - %s\n", pFileName);

	if (pFileName == NULL) {
		FWDNMessage(FWDN_RED_MSG, "pFileName == NULL\n");
		return false;
	}

	if (m_pFile == NULL) {
		m_pFile = fopen(pFileName, pMode);
		m_pFileName = CopyString(pFileName);
		SetBufSize(uiBufSize);
		m_pBuffer = (char*)malloc(uiBufSize);
		if (m_pFile != NULL) {
			FWDNFseek(m_pFile, 0, SEEK_END);
			m_ullFileSize = FWDNFtello64(m_pFile);
			rewind(m_pFile);
			return true;
		}
	}

	FWDNMessage(FWDN_RED_MSG, "Failed to open file - %s\n", pFileName);
	return false;
}

bool FWDNFile::Close()
{
	int ret = fclose(m_pFile);
	m_pFile = NULL;
	if(ret == 0) {
		return true;
	} else {
		FWDNMessage(FWDN_RED_MSG, "Failed to close file - %d\n", ret);
		//ENOTOPEN //The file is not open.
		//EIOERROR //A non-recoverable I/O error occurred.
		//EIORECERR //A recoverable I/O error occurred.
		//ESCANFAILURE //The file was marked with a scan failure.
		return false;
	}
}

void FWDNFile::Clear()
{
	if(m_pBuffer != NULL) {
		free(m_pBuffer);
		m_pBuffer = NULL;
	}

	if(m_pFileName != NULL) {
		free(m_pFileName);
		m_pFileName = NULL;
	}

	if(m_pFile != NULL) {
		Close();
	}

	m_ullFileSize = 0ULL;
}

char* FWDNFile::Read(unsigned long long ullSize, long long llOffset, int nOrigin, unsigned long long *pReadSize)
{
	if(m_pFile != NULL) {
		SetOffset(llOffset, nOrigin);
		return Read(ullSize, pReadSize);
	} else {
		FWDNMessage(FWDN_RED_MSG, "File is not openned\n");
		return NULL;
	}
}

char* FWDNFile::Read(unsigned long long ullSize, unsigned long long *pReadSize)
{
	if(m_pFile != NULL) {
		unsigned long long ullReadSize = fread(m_pBuffer, sizeof(char), ullSize, m_pFile);
		if(ullReadSize != ullSize) {
			FWDNMessage(FWDN_RED_MSG,
				"Failed to read file - readSize : %llu, requestSize : %llu\n", ullReadSize, ullSize);
		}
		if(pReadSize != NULL) {
			*pReadSize = ullReadSize;
		}
		return m_pBuffer;
	} else {
		FWDNMessage(FWDN_RED_MSG, "File is not openned\n");
		return NULL;
	}
}

bool FWDNFile::Write(char* pBuffer, unsigned long long ullSize)
{
	if(m_pFile != NULL) {
		if(fwrite(pBuffer, sizeof(char), ullSize, m_pFile) == ullSize) {
			return true;
		} else {
			FWDNMessage(FWDN_RED_MSG, "Failed to read file\n");
		}
	} else {
		FWDNMessage(FWDN_RED_MSG, "File is not openned\n");
	}
	return false;
}

bool FWDNFile::SetOffset(long long llOffset, int nOrigin)
{
	if(m_pFile != NULL) {
		if(FWDNFseek(m_pFile, llOffset, nOrigin) == 0) {
			return true;
		} else {
			FWDNMessage(FWDN_RED_MSG, "Failed to set offset\n");
		}
	} else {
		FWDNMessage(FWDN_RED_MSG, "File is not openned\n");
	}

	return false;
}

char* FWDNFile::CopyString(const char *pString)
{
	char *ret = NULL;
	unsigned int len = 0;

	if(pString) {
		len = strlen(pString);
		ret = (char*)malloc((len * sizeof(char)) + sizeof(char));
		if (ret) {
			strcpy(ret, pString);
		}
	}
	return ret;
}

void FWDNFile::SetBufSize(unsigned int uiBufSize)
{
	if(m_pBuffer != NULL) {
		free(m_pBuffer);
	}

	m_pBuffer = (char*)malloc(uiBufSize);
}