#pragma once

#include "config.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include "FWDNLogger.h"

#ifdef WINDOWS
#define FWDNFtello64(file) _ftelli64(file)
#define FWDNFseek(file, offset, origin) _fseeki64(file, offset, origin)
#else //LINUX
#define FWDNFtello64(file) ftello64(file)
#define FWDNFseek(file, offset, origin) fseeko64(file, offset, origin)
#endif

#define DEFAULT_BUF_SIZE (128 * 1024) //128 KB

class FWDNFile {
public:
	FWDNFile(const char* pFileName = NULL, const char* pMode = NULL, unsigned int uiBufSize = DEFAULT_BUF_SIZE);
	~FWDNFile();

public:
	bool Open(const char* pFileName, const char* pMode, unsigned int uiBufSize = DEFAULT_BUF_SIZE);
	bool Close();
	char* Read(unsigned long long ullSize, unsigned long long *pReadSize = NULL);
	char* Read(unsigned long long ullSize, long long llOffset, int nOrigin, unsigned long long *pReadSize = NULL);
	bool SetOffset(long long llOffset, int nOrigin);
	bool Write(char* pBuffer, unsigned long long ullSize);
	unsigned long long GetSize() {return m_ullFileSize;}
	void Clear();
	void SetBufSize(unsigned int uiBufSize);

private:
	char* CopyString(const char *pString);

	FILE* m_pFile;
	char* m_pBuffer;
	char* m_pFileName;
	unsigned long long m_ullFileSize;
};
