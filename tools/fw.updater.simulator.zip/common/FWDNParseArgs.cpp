#include "FWDNParseArgs.h"
#include "FWDNUtil.h"

#ifdef WINDOWS
#include "../windows/getopt.h"
#else //LINUX
#include <getopt.h>
#endif

struct option options[] = {
    {"help", no_argument, 0, 'h'},
	{"no-crc", no_argument, 0, 'c'},
	{"device-info", no_argument, 0, 'd'},
	{"debug", no_argument, 0, 'g'},
	{"low-format", no_argument, 0, 'l'},

	{"write", required_argument, 0, 'w'},
	{"read", required_argument, 0, 'r'},

	{"sector-size", required_argument, 0, 0},

	{"addr", required_argument, 0, 'a'},
	{"area", required_argument, 0, 'e'},
	{"part", required_argument, 0, 'p'},
	{"storage", required_argument, 0, 'm'},
	{"size", required_argument, 0, 's'},

	{"bank", required_argument, 0, 'b'},

//for fwdn rom file
	{"fwdn", required_argument, 0, 0},

//for hsm file
	{"hsm", required_argument, 0, 0},

//log option
	{"time", no_argument, 0, 0},
	{"save-log", no_argument, 0, 0},
	{"speed", no_argument, 0, 0},

//com port
	{"port", required_argument, 0, 0},
};


bool CheckLongOptions(int argc, char *argv[])
{
	int size = sizeof(options) / sizeof(option);
	bool find;
	char* temp;

	for(int i = 0; i < argc; i++) {
		if(strncmp(argv[i], "--", 2) != 0) {
			continue;
		}

		temp = argv[i] + 2;
		find = false;
		for(int j = 0; j < size; j++) {
			if(strcmp(options[j].name, temp) == 0){
				find = true;
				break;
			}
		}

		if(find == false) {
			FWDNMessage(FWDN_RED_MSG, "Invaild option : %s\n", argv[i]);
			return false;
		}
	}

	return true;
}

bool ParseArgs(int argc, char *argv[], FWDNArgs* param)
{
	int opt = -1;
	bool bRes = true;
	int index = 0;
	char* strOpt = NULL;

	if(argc <= 1) {
		bRes = false;
	}

	if(CheckLongOptions(argc, argv) == false) {
		return false;
	}

	while(1) {
		opt = getopt_long(argc, argv, "w:r:a:e:s:p:f:m:n:clhdg", options, &index);
		if(opt == -1) break; //End of Option

		switch(opt) {
		case 0:		//only long option
			if(strcmp("time", options[index].name) == 0) {
				param->bTimeStamp = true;
			}

			if(strcmp("save-log", options[index].name) == 0) {
				param->bSaveLog = true;
			}

			if(strcmp("speed", options[index].name) == 0) {
				param->bSpeed = true;
			}

			if(strcmp("fwdn", options[index].name) == 0) {
				param->pFWDNRomFileName = mallocString(optarg);
			}

			if(strcmp("hsm", options[index].name) == 0) {
				param->pHSMFileName = mallocString(optarg);
			}

			if(strcmp("sector-size", options[index].name) == 0) {
				convertHexStrToUll(optarg, &(param->ullSectorSize));

				if(param->ullSectorSize != 512/*FWDN_EMMC_SECTOR_SIZE*/
					&& param->ullSectorSize != 4096/*FWDN_UFS_SECTOR_SIZE*/) {
						FWDNMessage(FWDN_RED_MSG, "Sector size is supported only 512 and 4096\n");
						FWDNMessage(FWDN_RED_MSG, "Entered sector size : %llu\n", param->ullSectorSize);
					bRes = false;
				}
			}

			if(strcmp("port", options[index].name) == 0) {
				convertHexStrToUi(optarg, &(param->uiPort));
			}
			break;
		case 'b':	//bank
			convertHexStrToUi(optarg, &(param->uiBank));
			break;
		case 'w':	//write
			param->pWriteFileName = mallocString(optarg);
			break;
		case 'r':	//read
			param->pReadFileName = mallocString(optarg);
			break;
		case 'd':	//device-info
			param->bDeviceInfo = true;
			break;
		case 'm':	//memory
			param->pStorage = mallocString(optarg);
			break;
		case 'p':	//partition
			param->pPartitionName = mallocString(optarg);
			break;
		case 'e':	//area
			param->pArea = mallocString(optarg);
			break;
		case 'a':	//address
			bRes = convertHexStrToUll(optarg, &(param->ullAddr));
			break;
		case 's':	//size
			bRes = convertHexStrToUll(optarg, &(param->ullSize));
			break;
		case 'l':	//low-format
			param->bLowFormat = true;
			break;
		case 'h':	//help
			PrintHelpMsg();
			return false;
		case 'g':	//debug message
			param->bDebugMode = true;
			break;
		default:
			bRes = false;
			break;
		}
	}

    if(bRes == false) {
		printf("Try '--help' for more information.\n");
	}

	param->ullAddr = SectorToByte(param->ullAddr, param->ullSectorSize);
	param->ullSize = SectorToByte(param->ullSize, param->ullSectorSize);

	return bRes;
}

bool CheckStorageOption(FWDNArgs* pFwdnArgs)
{
	if(StrToUintStorageType(pFwdnArgs->pStorage) == 0) {	//unknown type
		FWDNMessage(FWDN_RED_MSG, "Need to valid storage option\n");
		return false;
	}

	return true;
}

void PrintHelpMsg(void)
{
	printf(
"Usage : fwdn_vcp <command> <options>\n"
"\n"
"Example:\n"
"  Start to fwdn(load FWDN F/W) :\n"
"    fwdn_vcp.exe --fwdn fwdn_vcp.rom --hsm hsm.bin\n"
"  Download file :\n"
"    fwdn_vcp -w [file name] --bank 0\n"
"    fwdn_vcp -w [file name] --bank 1\n"
"  Read dump :\n"
"    fwdn_vcp -r [file name] --bank 0\n"
"    fwdn_vcp -r [file name] --bank 1 --size 0x100 --add 0x1234\n"
"  Erase storage(Low format) :\n"
"    fwdn_vcp --low-format --storage [storage type]\n"
"  Print storage info\n"
"    fwdn_vcp --device-info\n"
"\n"
"Commands:\n"
"  -w, --write [file name]       Write data\n"
"  -r, --read [file name]        Read data\n"
"      --low-format              Erase storage\n"
"  -h, --help                    Print help\n"
"\n"
"Options:\n"
"  -b, --bank [bank num]         Set target bank for 'write' and 'read'\n"
"                                bank 0, bank 1\n"
"  -a, --addr [address(sector)]  Set start address for 'write' and 'read'\n"
"                                Address entered is in sector units\n"
"                                Default 1 secotr : 512 bytes\n"
"  -s, --size [size(sector)]     Set size for 'write' and 'read'\n"
"                                Size entered is in sector units\n"
"                                Default 1 secotr : 512 bytes\n"
"      --sector-size             Set sector size of storage\n"
"                                Default value : 512 bytes\n"
"                                Only 512 and 4096 are supported\n"
"  -c, --no-crc                  No check crc\n"
"      --fwdn [fwdn rom]         Set fwdn mandatory file(fwdn.rom)\n"
"                                fwdn rom : fwdn firmware to be executed in sram is designated\n"
"      --hsm [vcp rom]           This option is required when reading\n"
"                                Get hsm from vcp rom\n"
"                                hsm : hsm firmware to verify fwdn rom file\n"
"      --debug                   Print debug message\n"
"                                You can see more detailed message\n"
"      --time                    Print time stamp\n"
"                                You can see [min:sec:ms]\n"
"      --save-log                Save message\n"
"      --device-info             Print storage info\n"
"      --speed                   Print download or dump speed\n"
"\n"
"Caution:\n"
"  If you want to enter in hexadecimal, prefix the value with '0x'\n"
"     ex) hex : 0x123, dec : 123\n"
"  File path token Linux = '/', Windows = '\\'\n"
	);
}
