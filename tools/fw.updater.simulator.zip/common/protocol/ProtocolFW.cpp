#include "ProtocolFW.h"

ProtocolFW::ProtocolFW(CSerialPort *serial)
:
m_serial(serial),
m_uiPacketSize(sizeof(unsigned int) * 6)
{
}

bool  ProtocolFW::SendCommand(CmdPacket *pCmd)
{
	unsigned long ulResultSize;
	bool ret;

	if (pCmd == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] pCmd == NULL\n");
		return false;
	}

	if (m_serial == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] m_serial == NULL\n");
		return false;
	}

	ret = m_serial->SendData(pCmd, PacketSize(), &ulResultSize);
	if (ret == false) {
		FWDNMessage(FWDN_RED_MSG,
			"Failed send data(%lu / %lu)\n",
			ulResultSize, PacketSize());
		return false;
	}

	FWDNSleep(20);	//for stable
	return ret;
}

bool ProtocolFW::RecvResponse(
	unsigned int uiCmdType, CmdPacket *pRes, unsigned int uiTimeout)
{
	unsigned long ulResultSize;
	bool ret;
	CmdPacket res;

	if (pRes == NULL) {
		pRes = &res;
	}

	memset(pRes, 0, PacketSize());
	do {
		ret = m_serial->ReadDataTimeout(
			pRes, PacketSize(), &ulResultSize, uiTimeout);
	} while (ret == false);

	ret = CheckResPacket(pRes, uiCmdType, NULL);
	return ret;
}

bool ProtocolFW::RecvData(
	char *pbuff, unsigned int uiSize, unsigned int uiTimeout)
{
	unsigned long ulResultSize;
	bool ret;

	if (pbuff == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"pbuff == NULL\n");
		return false;
	}

	do {
		ret = m_serial->ReadDataTimeout(
			pbuff, uiSize, &ulResultSize, uiTimeout);
	} while (ret == false);

	return ret;
}

bool ProtocolFW::SendFile(char *pFileName, unsigned int uiOffset, unsigned int uiSize)
{
	unsigned int uiCalcCRC = 0;
	unsigned int uiBunch;
	unsigned int uiRemainSize;
	unsigned long ulResultSize;
	char *buf;
	CmdPacket cmd;
	FWDNFile file(pFileName, "rb");

	memset(&cmd, 0, PacketSize());
	if (uiSize == 0) {
		uiRemainSize = file.GetSize() & MASK_OF_32BITS;
	} else {
		uiRemainSize = uiSize;
	}
	file.SetOffset(uiOffset, SEEK_SET);
	ProgressBar::GetIns()->SetTotalSize(
		(unsigned long long)uiRemainSize);

	while (uiRemainSize != 0) {
		if (uiRemainSize >= m_uiBunchSize) {
			uiBunch = m_uiBunchSize;
		} else {
			uiBunch = uiRemainSize;
		}

		buf = file.Read(uiBunch);
		uiCalcCRC = CalcCRC32(buf, uiBunch, uiCalcCRC);

		do {
			cmd.uiCmdType = VCP_ACK;
			cmd.uiParam0 = uiCalcCRC;
			m_serial->SendData(&cmd, PacketSize(), &ulResultSize);
			m_serial->SendData(buf, uiBunch, &ulResultSize);
			m_serial->ReadData(&cmd, PacketSize(), &ulResultSize);
		} while((cmd.uiCmdType == VCP_NACK)
			&& (cmd.uiParam1 == VCP_FAIL_CALC_CRC_FILE));

		if (cmd.uiCmdType != VCP_NYET) {
			FWDNMessage(FWDN_RED_MSG,
				"Failed to send file\n");
			DumpPacket(FWDN_RED_MSG, &cmd);
			return false;
		} else {
			uiRemainSize -= uiBunch;
			ProgressBar::GetIns()->Plus(uiBunch);
		}
	}
	ProgressBar::GetIns()->End();
	FWDNMessage(FWDN_WHITE_MSG,
			"Complete to send file\n");

	return true;
}

bool ProtocolFW::DumpProtocol(
	FWDNFile &file, unsigned int uiCmdType, unsigned int uiRequestSize)
{
	unsigned long ulResultSize;
	unsigned int uiCalcCRC;
	bool ret;
	CmdPacket res;

	if (m_serial == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] m_serial == NULL\n");
		return false;
	}

	if (RecvDataAndCreateFile(file, uiCmdType, uiRequestSize, &uiCalcCRC)
			== true) {
		memset(&res, 0, PacketSize());
		ret = false;
		while (ret == false) {
			ret = m_serial->ReadData(
				&res, PacketSize(), &ulResultSize);
		}

		ret = CheckResPacket(&res, uiCmdType, &uiCalcCRC);
		return ret;
	}

	return false;
}

bool ProtocolFW::RecvDataAndCreateFile(
	FWDNFile &file, unsigned int uiCmdType,
	unsigned int uiRequestSize, unsigned int *pCRC)
{
	unsigned int uiBunch, uiRemainSize;
	unsigned int uiCalcCRC = 0;
	unsigned int uiPreCalcCRC = 0;
	unsigned long ulResultSize;
	bool ret;
	char buf[m_uiBunchSize];
	CmdPacket res;
	//FWDNFile file(pFileName, "wb");

	memset(&res, 0, PacketSize());

	if (m_serial == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] m_serial == NULL\n");
		return false;
	}

	if (pCRC == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] pCRC == NULL\n");
		return false;
	}

	uiRemainSize = uiRequestSize;
	ProgressBar::GetIns()->SetTotalSize(
		(unsigned long long)uiRemainSize);

	*pCRC = 0;
	while (uiRemainSize != 0) {
		if (uiRemainSize >= m_uiBunchSize) {
			uiBunch = m_uiBunchSize;
		} else {
			uiBunch = uiRemainSize;
		}

		if (m_serial->ReadData(&res, PacketSize(), &ulResultSize)
				== false) {
			return false;
		}
		if (m_serial->ReadData(buf, uiBunch, &ulResultSize)
				== false) {
			return false;
		}

		uiPreCalcCRC = *pCRC;
		*pCRC = CalcCRC32(buf, ulResultSize, *pCRC);

		if (*pCRC != res.uiParam1) {
			res.uiCmdType = VCP_NACK;
			res.uiParam1 = VCP_FAIL_CALC_CRC_FILE;

			*pCRC = uiPreCalcCRC;
		} else {
			file.Write(buf, (unsigned long long)ulResultSize);
			ProgressBar::GetIns()->Plus(ulResultSize);
			uiRemainSize -= ulResultSize;
			res.uiCmdType = VCP_NYET;
		}

		res.uiParam0 = uiCmdType;
		ret = m_serial->SendData(
			&res, PacketSize(), &ulResultSize);
	}

	ProgressBar::GetIns()->End();

	FWDNMessage(FWDN_WHITE_MSG,
			"Complete to receive storage dump data\n");

	return true;
}

bool ProtocolFW::CheckResPacket(
	CmdPacket *pRes, unsigned int uiCmdType, unsigned int *pCalcCRC)
{
	std::string strCmd;

	if (pRes == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] pRes == NULL\n");
		return false;
	}

	GetDefineStr(pRes->uiParam0, &strCmd);

	if ((pRes->uiParam0 == uiCmdType)
		&& (pRes->uiCmdType == VCP_ACK)) {
		FWDNMessage(FWDN_WHITE_MSG,
			"Complete to receive ack for cmd(0x%X(%s))\n",
			pRes->uiParam0, strCmd.c_str());
		if (pCalcCRC != NULL) {
			unsigned int uiReceivedCRC = pRes->uiParam1;
			if (*pCalcCRC != uiReceivedCRC) {
				FWDNMessage(FWDN_RED_MSG,
					"Receved CRC : %x, Calculated CRC : %x\n",
					uiReceivedCRC, *pCalcCRC);
				return false;
			}
			FWDNMessage(FWDN_WHITE_MSG,
				"Receved CRC : %x, Calculated CRC : %x\n",
				uiReceivedCRC, *pCalcCRC);
		}
		return true;
	}

	if (uiCmdType != VCP_FW_PING) {
		if (pRes->uiParam0 != uiCmdType) {
			FWDNMessage(FWDN_RED_MSG,
				"Invalid cmd of res(0x%X(%s))\n",
				pRes->uiParam0, strCmd.c_str());
		} else if (pRes->uiCmdType == VCP_NACK) {
			FWDNMessage(FWDN_RED_MSG, "Received NACK\n");
		} else {
			FWDNMessage(FWDN_RED_MSG, "Unknown response\n");
		}

		DumpPacket(FWDN_RED_MSG, pRes);
	}

	return false;
}

void ProtocolFW::DumpPacket(unsigned int uiMsgType, CmdPacket *pPacket)
{
	std::string strCmd;
	std::string strParam[5];

	GetDefineStr(pPacket->uiCmdType, &strCmd);
	GetDefineStr(pPacket->uiParam0, &strParam[0]);
	GetDefineStr(pPacket->uiParam1, &strParam[1]);
	GetDefineStr(pPacket->uiParam2, &strParam[2]);
	GetDefineStr(pPacket->uiParam2, &strParam[3]);
	GetDefineStr(pPacket->uiParam2, &strParam[4]);

	if (pPacket == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] pPacket == NULL\n");
	} else {
		FWDNMessage(uiMsgType,
			"Dump Packet\n"
			"\tCmd type : 0x%X(%s)\n"
			"\tParam0 : 0x%X(%s)\n"
			"\tParam1 : 0x%X(%s)\n"
			"\tParam2 : 0x%X(%s)\n"
			"\tParam3 : 0x%X(%s)\n"
			"\tParam4 : 0x%X(%s)\n",
			pPacket->uiCmdType, strCmd.c_str(),
			pPacket->uiParam0, strParam[0].c_str(),
			pPacket->uiParam1, strParam[1].c_str(),
			pPacket->uiParam2, strParam[2].c_str(),
			pPacket->uiParam2, strParam[3].c_str(),
			pPacket->uiParam2, strParam[4].c_str());
	}
}

CmdPacket ProtocolFW::MakeCmdPacket(unsigned int uiCmd, FWDNArgs *pFwdnArgs)
{
	CmdPacket cmd;
	char *pFileName = NULL;
	FWDNFile file;
	unsigned int uiRequestSize;

	memset(&cmd, 0, sizeof(CmdPacket));
	cmd.uiCmdType = uiCmd;

	if (uiCmd == VCP_WRITE_CMD) {
		if (pFwdnArgs == NULL) {
			FWDNMessage(FWDN_RED_MSG, "[ERROR] pFwdnArgs == NULL\n");
			return cmd;
		}

		if (pFwdnArgs->pWriteFileName == NULL) {
			FWDNMessage(FWDN_RED_MSG, "[ERROR] pWriteFileName == NULL\n");
			//return false;
			//TODO: change
			return cmd;
		}

		pFileName = pFwdnArgs->pWriteFileName;
		file.Open(pFileName, "rb");

		if (pFwdnArgs->ullSize != 0) {
			uiRequestSize = (pFwdnArgs->ullSize) & MASK_OF_32BITS;
		} else {
			uiRequestSize = file.GetSize() & MASK_OF_32BITS;
		}

		cmd.uiParam0 = StrToUintStorageType(pFwdnArgs->pStorage);
		cmd.uiParam1 = uiRequestSize;
		cmd.uiParam2 = (pFwdnArgs->ullAddr) & MASK_OF_32BITS;
		cmd.uiParam3 = CalcCRCInFile(&file, uiRequestSize);
	} else if (uiCmd == VCP_READ_CMD) {
		if (pFwdnArgs == NULL)  {
			FWDNMessage(FWDN_RED_MSG, "[ERROR] pFwdnArgs == NULL\n");
			return cmd;
		}

		if (pFwdnArgs->pReadFileName == NULL) {
			FWDNMessage(FWDN_RED_MSG, "[ERROR] pReadFileName == NULL\n");
			//return false;
			//TODO: change
			return cmd;
		}

		cmd.uiParam0 = StrToUintStorageType(pFwdnArgs->pStorage);
		cmd.uiParam1 = (pFwdnArgs->ullSize) & MASK_OF_32BITS;
		cmd.uiParam2 = (pFwdnArgs->ullAddr) & MASK_OF_32BITS;
	} else {
		//VCP_STORAGE_INFO_CMD
		//VCP_FW_PING
		//VCP_LOW_FORMAT_CMD

		//all params : 0
	}

	cmd.uiParam4 = CalcCRC32(
				(char*)&cmd, PacketSize() - sizeof(unsigned int), 0);

	return cmd;
}
