#pragma once

/* Chip boot define */
#define VCP_START_CMD			0x44555746  // "FWUD"
#define VCP_RECEIVE_HSM_CMD		0xFFFF0000U
#define VCP_RECEIVE_FWDN_CMD	0xFFFF0001U

/* common define */
#define VCP_ACK					0xFFFF0010U
#define VCP_NACK				0xFFFF0011U
#define VCP_NYET				0xFFFF0012U

#define VCP_FAIL_CALC_CRC_FILE	0xFFFF0100U
#define VCP_INVALID_CMD			0xFFFF0101U
#define VCP_FAIL_CALC_CRC_CMD	0xFFFF0102U

/* FWDN F/W define */
//TODO: change value
#define VCP_READY_CMD			0xAAAA0010U
#define VCP_WRITE_CMD			0xAAAA0011U
#define VCP_VERSION_CMD			0xAAAA0012U
#define VCP_CHIP_INFO_CMD		0xAAAA0013U
//TODO: RESERVED
#define VCP_READ_CMD			0xAAAA0014U
#define VCP_FW_PING				0xAAAA0015U
#define VCP_STORAGE_INFO_CMD	0xAAAA0016U
#define VCP_LOW_FORMAT_CMD		0xAAAA0017U

#define VCP_SNOR				0xAAAA1001U
#define VCP_EFLASH				0xAAAA1002U

#include "../../windows/SerialPort.h"
#include "../FWDNLogger.h"
#include "../FWDNUtil.h"
#include <string>

struct CmdPacket {
	unsigned int uiCmdType;
	unsigned int uiParam0;
	unsigned int uiParam1;
	unsigned int uiParam2;	//Use in chipboot

	unsigned int uiParam3;
	unsigned int uiParam4;	//Use in FWDN Firmware
};

class FwdnProtocol {
public:
	virtual bool SendCommand(CmdPacket *pCmd) = 0;
	//virtual bool SendCommand(unsigned int uiCmdType, unsigned int uiFileCRC, unsigned int uiFileSize) = 0;
	virtual bool RecvResponse(unsigned int uiCmdType, CmdPacket *pRes, unsigned int uiTimeout = 0) = 0;
	virtual CmdPacket MakeCmdPacket(unsigned int uiCmd, FWDNArgs *pFwdnArgs = NULL) = 0;
	virtual unsigned int PacketSize() = 0;

private:
	virtual bool SendFile(char *pFileName, unsigned int uiOffset = 0, unsigned int uiSize = 0) = 0;
	virtual bool CheckResPacket(CmdPacket *pRes, unsigned int uiCmdType, unsigned int *pCalcCRC = NULL) = 0;

protected:
	virtual CSerialPort *GetSerial() = 0;

public:
	bool SendFileAndRecvRes(char *pFileName, unsigned int uiCmdType, unsigned int uiOffset = 0, unsigned int uiSize = 0);
	void GetDefineStr(unsigned int uiDefine, std::string *str);
};
