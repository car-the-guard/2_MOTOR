#include "FwdnProtocol.h"

bool FwdnProtocol::SendFileAndRecvRes(
	char *pFileName, unsigned int uiCmdType, unsigned int uiOffset, unsigned int uiSize)
{
	unsigned long ulResultSize;
	bool ret;
	CmdPacket res;
	unsigned int uiCalcCRC;

	if (GetSerial() == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] GetSerial() == NULL\n");
		return false;
	}

	if (SendFile(pFileName, uiOffset, uiSize) == true) {
		FWDNFile file(pFileName, "rb");

		uiCalcCRC = CalcCRCInFile(&file, (unsigned long long)uiOffset, (unsigned long long)uiSize);
		memset(&res, 0, PacketSize());
		do {
			ret = GetSerial()->ReadData(
				&res, PacketSize(), &ulResultSize);
		} while (ret == false);

		ret = CheckResPacket(&res, uiCmdType, &uiCalcCRC);
		return ret;
	}
	
	return false;
}

void FwdnProtocol::GetDefineStr(unsigned int uiDefine, std::string *str)
{
//	#define DEFINE_TO_STR(DEFINE_STR)	(#DEFINE_STR)

	switch (uiDefine) {
		case VCP_ACK:
			*str = "ACK";
			break;
		case VCP_NACK:
			*str = "NACK";
			break;
		case VCP_FAIL_CALC_CRC_FILE:
			*str = "FAIL_CALC_CRC_FILE";
			break;
		case VCP_INVALID_CMD:
			*str = "INVALID_CMD";
			break;
		case VCP_FAIL_CALC_CRC_CMD:
			*str = "FAIL_CALC_CRC_CMD";
			break;
		case VCP_START_CMD:
			*str = "START_CMD";
			break;
		case VCP_RECEIVE_HSM_CMD:
			*str = "RECEIVE_HSM_CMD";
			break;
		case VCP_RECEIVE_FWDN_CMD:
			*str = "RECEIVE_FWDN_CMD";
			break;
		case VCP_FW_PING:
			*str = "FW_PING";
			break;
		case VCP_WRITE_CMD:
			//*str = DEFINE_TO_STR(VCP_WRITE_CMD);
			*str = "WRITE_CMD";
			break;
		case VCP_READ_CMD:
			//*str = DEFINE_TO_STR(VCP_READ_CMD);
			*str = "READ_CMD";
			break;
		case VCP_STORAGE_INFO_CMD:
			*str = "STORAGE_INFO_CMD";
			break;
		case VCP_LOW_FORMAT_CMD:
			*str = "LOW_FORMAT_CMD";
			break;
		case VCP_VERSION_CMD:
			*str = "VERSION_CMD";
			break;
		case VCP_CHIP_INFO_CMD:
			*str = "CHIP_INFO_CMD";
			break;
		default:
			*str = "Unknown define";
			break;
	}
}