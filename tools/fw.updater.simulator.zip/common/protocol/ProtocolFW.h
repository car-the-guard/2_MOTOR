#pragma once

#include "FwdnProtocol.h"
#include "../FWDNLogger.h"
#include "../FWDNFile.h"
#include "../FWDNUtil.h"
#include <string>

//Protocol In FWDN Firmeware
class ProtocolFW : public FwdnProtocol {
public:
	ProtocolFW(CSerialPort *serial);

public:
	virtual bool SendCommand(CmdPacket *pCmd);
	virtual bool RecvResponse(unsigned int uiCmdType, CmdPacket *pRes, unsigned int uiTimeout = 0);
	virtual CmdPacket MakeCmdPacket(unsigned int uiCmd, FWDNArgs *pFwdnArgs = NULL);
	virtual unsigned int PacketSize() { return m_uiPacketSize; }

private:
	virtual bool SendFile(char *pFileName, unsigned int uiOffset = 0, unsigned int uiSize = 0);
	virtual bool CheckResPacket(CmdPacket *pRes, unsigned int uiCmdType, unsigned int *pCalcCRC = NULL);
	virtual CSerialPort *GetSerial() { return m_serial; }

public:
	bool DumpProtocol(FWDNFile &file, unsigned int uiCmdType, unsigned int uiRequestSize);
	bool RecvData(char *pbuff, unsigned int uiSize, unsigned int uiTimeout = 0);

private:
	bool RecvDataAndCreateFile(FWDNFile &file, unsigned int uiCmdType, unsigned int uiRequestSize, unsigned int * pCRC);
	void DumpPacket(unsigned int uiMsgType, CmdPacket *pPacket);

private:
	static const unsigned int m_uiBunchSize = 4096; //2KB
	CSerialPort *m_serial;
	unsigned int m_uiPacketSize;
};