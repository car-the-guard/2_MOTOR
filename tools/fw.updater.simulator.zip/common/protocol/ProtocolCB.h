#pragma once

#include "FwdnProtocol.h"
#include "../FWDNLogger.h"
#include "../FWDNFile.h"
#include "../FWDNUtil.h"
#include <string>

//Protocol In Chip Boot
class ProtocolCB : public FwdnProtocol {
public:
	ProtocolCB(CSerialPort *serial);

public:
	virtual bool SendCommand(CmdPacket *pCmd);
	virtual bool RecvResponse(unsigned int uiCmdType, CmdPacket *pRes, unsigned int uiTimeout = 0);
	virtual CmdPacket MakeCmdPacket(unsigned int uiCmd, FWDNArgs *pFwdnArgs = NULL);
	virtual unsigned int PacketSize() { return m_uiPacketSize; }

private:
	virtual bool SendFile(char *pFileName, unsigned int uiOffset = 0, unsigned int uiSize = 0);
	virtual CSerialPort *GetSerial() { return m_serial; }

public:
	bool StartVCPFWDN();

private:
	virtual bool CheckResPacket(CmdPacket *pRes, unsigned int uiCmdType, unsigned int *pCalcCRC = NULL);
	void DumpPacket(unsigned int uiMsgType, CmdPacket *pPacket);

private:
	static const unsigned int m_uiBunchSize = 4;
	CSerialPort *m_serial;
	unsigned int m_uiPacketSize;
};