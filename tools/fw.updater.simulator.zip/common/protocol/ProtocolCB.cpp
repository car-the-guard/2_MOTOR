#include "ProtocolCB.h"

ProtocolCB::ProtocolCB(CSerialPort *serial)
:
m_serial(serial),
m_uiPacketSize(sizeof(unsigned int) * 4)
{
}

bool ProtocolCB::StartVCPFWDN()
{
	unsigned long ulResultSize;
	bool ret;
	CmdPacket cmd;
	CmdPacket res;
	unsigned int uiRetry = 0;

	memset(&res, 0, PacketSize());
	memset(&cmd, 0, PacketSize());
	cmd.uiCmdType = VCP_START_CMD;

	if (m_serial == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] m_serial == NULL\n");
		return false;
	}

	m_serial->SetCommunicationTimeouts(10, 10, 10, 10, 10);
	while (1) {
		ret = m_serial->SendData(&cmd, PacketSize(), &ulResultSize);
		if(ret == false) {
			FWDNMessage(FWDN_RED_MSG,
				"Failed send data(%lu / %lu)\n",
				ulResultSize, PacketSize());
			break;
		}

		ret = m_serial->ReadDataTimeout(&res, PacketSize(), &ulResultSize, 1);
		if (ret == false) {
			continue;
		}

		if (res.uiParam0 == cmd.uiCmdType
				&& res.uiCmdType == VCP_ACK) {
			FWDNMessage(FWDN_WHITE_MSG, "Complete to receive start res\n");
			m_serial->ReadDataTimeout(&res, 50, &ulResultSize, 1);//clear buffer
			return true;
		}

		printf("\rRetry : %d", uiRetry++);
		if (uiRetry > 30) {
			printf("\n");
			FWDNMessage(FWDN_RED_MSG, "Please reset target board and retry fwdn\n");
			return false;
		}
	}

	return false;
}

bool ProtocolCB::SendCommand(CmdPacket *pCmd)
{
	unsigned long ulResultSize;
	bool ret;

	if (pCmd == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] pCmd == NULL\n");
		return false;
	}

	if (m_serial == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] m_serial == NULL\n");
		return false;
	}

	ret = m_serial->SendData(pCmd, PacketSize(), &ulResultSize);
	if (ret == false) {
		FWDNMessage(FWDN_RED_MSG,
			"Failed send data(%lu / %lu)\n",
			ulResultSize, PacketSize());
		return false;
	}

	FWDNSleep(20);	//for stable
	return ret;
}

bool ProtocolCB::RecvResponse(
	unsigned int uiCmdType, CmdPacket *pRes, unsigned int uiTimeout)
{
	unsigned long ulResultSize;
	bool ret;
	CmdPacket res;

	if (pRes == NULL) {
		pRes = &res;
	}

	memset(pRes, 0, PacketSize());
	do {
		ret = m_serial->ReadDataTimeout(
			pRes, PacketSize(), &ulResultSize, uiTimeout);
	} while (ret == false);

	ret = CheckResPacket(pRes, uiCmdType);
	return ret;
}

bool ProtocolCB::SendFile(char *pFileName, unsigned int uiOffset, unsigned int uiSize)
{
	char *buf;
	unsigned int uiBunch;
	unsigned int uiRemainSize;
	unsigned long ulResultSize;
	FWDNFile file(pFileName, "rb");

	if (uiSize == 0) {
		uiRemainSize = file.GetSize() & MASK_OF_32BITS;
	} else {
		uiRemainSize = HSM_SIZE; //HSM hard fix
	}
	file.SetOffset(uiOffset, SEEK_SET);

	ProgressBar::GetIns()->SetTotalSize(
		(unsigned long long)uiRemainSize);

	while (uiRemainSize != 0) {
		if (uiRemainSize >= m_uiBunchSize) {
			uiBunch = m_uiBunchSize;
		} else {
			uiBunch = uiRemainSize;
		}

		buf = file.Read(uiBunch);
		m_serial->SendData(buf, (unsigned long long)uiBunch, &ulResultSize);

		uiRemainSize -= ulResultSize;
		ProgressBar::GetIns()->Plus(ulResultSize);
	}

	ProgressBar::GetIns()->End();
	FWDNMessage(FWDN_WHITE_MSG,
			"Complete to send file\n");
	return true;
}

bool ProtocolCB::CheckResPacket(
	CmdPacket *pRes, unsigned int uiCmdType, unsigned int *pCalcCRC)
{
	std::string strCmd;

	if (pRes == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] pRes == NULL\n");
		return false;
	}

	GetDefineStr(pRes->uiParam0, &strCmd);

	if ((pRes->uiParam0 == uiCmdType)
			&& (pRes->uiCmdType == VCP_ACK)) {
		FWDNMessage(FWDN_WHITE_MSG,
			"Complete to receive ack for cmd(0x%X(%s))\n",
			pRes->uiParam0, strCmd.c_str());
		return true;
	}  else {
		if (pRes->uiParam0 != uiCmdType) {
			FWDNMessage(FWDN_RED_MSG,
			"Invalid cmd of res(0x%X(%s))\n",
			pRes->uiParam0, strCmd.c_str());
		} else if (pRes->uiCmdType == VCP_NACK) {
			FWDNMessage(FWDN_RED_MSG, "Received NACK\n");
		} else {
			FWDNMessage(FWDN_RED_MSG, "Unknown response\n");
		}
		DumpPacket(FWDN_RED_MSG, pRes);
	}

	return false;
}

void ProtocolCB::DumpPacket(unsigned int uiMsgType, CmdPacket *pPacket)
{
	std::string strCmd;
	std::string strParam[3];

	GetDefineStr(pPacket->uiCmdType, &strCmd);
	GetDefineStr(pPacket->uiParam0, &strParam[0]);
	GetDefineStr(pPacket->uiParam1, &strParam[1]);
	GetDefineStr(pPacket->uiParam2, &strParam[2]);

	if (pPacket == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] pPacket == NULL\n");
	} else {
		FWDNMessage(uiMsgType,
			"Dump Packet\n"
			"\tCmd type : 0x%X(%s)\n"
			"\tParam0 : 0x%X(%s)\n"
			"\tParam1 : 0x%X(%s)\n"
			"\tParam2 : 0x%X(%s)\n",
			pPacket->uiCmdType, strCmd.c_str(),
			pPacket->uiParam0, strParam[0].c_str(),
			pPacket->uiParam1, strParam[1].c_str(),
			pPacket->uiParam2, strParam[2].c_str());
	}
}

CmdPacket ProtocolCB::MakeCmdPacket(unsigned int uiCmd, FWDNArgs *pFwdnArgs)
{
	CmdPacket cmd;
	FWDNFile file;

	memset(&cmd, 0, sizeof(CmdPacket));
	cmd.uiCmdType = uiCmd;

	switch (uiCmd) {
		case VCP_RECEIVE_FWDN_CMD:
			file.Open(pFwdnArgs->pWriteFileName, "rb");
			cmd.uiParam0 = file.GetSize() & MASK_OF_32BITS;
			cmd.uiParam1 = CalcCRCInFile(pFwdnArgs->pWriteFileName);
			break;
		case VCP_RECEIVE_HSM_CMD:
			file.Open(pFwdnArgs->pWriteFileName, "rb");
			cmd.uiParam0 = HSM_SIZE; //64 kb //file.GetSize() & MASK_OF_32BITS;
			file.SetOffset(HSM_OFFSET, SEEK_SET);
			cmd.uiParam1 = CalcCRC32(file.Read(HSM_SIZE), HSM_SIZE, 0);
			//cmd.uiParam1 = CalcCRCInFile(pFwdnArgs->pWriteFileName);
			break;
		case VCP_START_CMD:
		default:
			//all params : 0
			break;
	}

	cmd.uiParam2 = CalcCRC32(
		(char*)&cmd, PacketSize() - sizeof(unsigned int), 0);

	return cmd;
}
