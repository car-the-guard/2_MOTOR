#pragma once

#include "config.h"
#include <ctime>

#define PROGRESS_BAR_STR "||||||||||||||||||||||||||||||"
#define PROGRESS_BAR_SIZE 30

class ProgressBar {
private:
	ProgressBar();
	static ProgressBar* m_pProgressBar;

public:
	static ProgressBar* GetIns();
	~ProgressBar();

	void PrintProgress(unsigned long long ull);
	bool Plus(unsigned long long ull);
	void EraseProgressBar();
	bool IsPrint() {return m_bPrint;}
	bool IsStart() {return m_bStart;}
	void End() {m_bStart = false;}
	void SetTotalSize(unsigned long long ullTotal);
	void SetShowSpeed(bool bShow) {m_bShowSpeed = bShow;}

private:
	unsigned long long GetPercent(unsigned long long ull, unsigned long long ullTotal);

private:
	clock_t m_startTime;
	unsigned long long m_ullCurrent;
	unsigned long long m_ullTotal;
	bool m_bPrint;
	bool m_bStart;
	bool m_bShowSpeed;
};