#pragma once

#include <iostream>
#include <vector>

const unsigned int TCC7022_CHIP_NUM = 0xFFF57022;
const unsigned int TCC7022_SE_CHIP_NUM = 0x57022;
const unsigned int TCC7025_CHIP_NUM = 0xFFF57025;
const unsigned int TCC7025_SE_CHIP_NUM = 0x57025;
const unsigned int TCC7035_CHIP_NUM = 0x17035;
const unsigned int TCC7035_SE_CHIP_NUM = 0x57035;
const unsigned int TCC7045_CHIP_NUM = 0x17045;
const unsigned int TCC7045_SE_CHIP_NUM = 0xFFF57045;

const unsigned int SIZE_2MB = 2 * 1024 * 1024;
const unsigned int SIZE_1MB = 1 * 1024 * 1024;
const unsigned int SIZE_1780KB = 1780 * 1024;
const unsigned int OFFSET_2MB = SIZE_2MB;
const unsigned int OFFSET_1MB = SIZE_1MB;

struct vcp_chip_info {
	unsigned int uiChipNumber;
	bool bExpandSnor;
	bool bEcc;
	bool bDualBank;
};

struct vcp_bank_info {
	unsigned int uiBankNum;
	unsigned int uiEflashSize;
	unsigned int uiEflashOffset;
	unsigned int uiSnorSize;
	unsigned int uiSnorOffset;
};

struct vcp_chip_bank_info {
	vcp_chip_info chipInfo;
	vcp_bank_info bankInfo;
};

const unsigned int MAX_BANK_INFO = 36;
const vcp_chip_bank_info chip_bank_info_list[MAX_BANK_INFO] = {
	//struct vcp_chip_info                              //struct vcp_bank_info
	//Chip number			/Exapnd		/ecc	/dual	//bank num	/eflash size	/eflash offset	/snor size		/snor offset
	{ TCC7022_CHIP_NUM,		false,		false,	false,	0,			SIZE_2MB,		0,				0,				0},
	{ TCC7022_CHIP_NUM,		false,		false,	true,	0,			SIZE_1MB,		0,				0,				0},
	{ TCC7022_CHIP_NUM,		false,		false,	true,	1,			SIZE_1MB,		OFFSET_1MB,		0,				0},

	{ TCC7022_SE_CHIP_NUM,	false,		true,	false,	0,			SIZE_2MB,		0,				0,				0},
	{ TCC7022_SE_CHIP_NUM,	false,		true,	true,	0,			SIZE_1MB,		0,				0,				0},
	{ TCC7022_SE_CHIP_NUM,	false,		true,	true,	1,			SIZE_1MB,		OFFSET_1MB,		0,				0},

	{ TCC7025_CHIP_NUM,		false,		false,	false,	0,			SIZE_2MB,		0,				0,				0},
	{ TCC7025_CHIP_NUM,		false,		false,	true,	0,			SIZE_1MB,		0,				0,				0},
	{ TCC7025_CHIP_NUM,		false,		false,	true,	1,			SIZE_1MB,		OFFSET_1MB,		0,				0},

	{ TCC7025_SE_CHIP_NUM,	false,		true,	false,	0,			SIZE_2MB,		0,				0,				0},
	{ TCC7025_SE_CHIP_NUM,	false,		true,	true,	0,			SIZE_1MB,		0,				0,				0},
	{ TCC7025_SE_CHIP_NUM,	false,		true,	true,	1,			SIZE_1MB,		OFFSET_1MB,		0,				0},

	{ TCC7035_CHIP_NUM,		false,		false,	false,	0,			SIZE_2MB,		0,				0,				0},
	{ TCC7035_CHIP_NUM,		true,		false,	false,	0,			SIZE_2MB,		0,				SIZE_1MB,		0},
	{ TCC7035_CHIP_NUM,		false,		false,	true,	0,			SIZE_1MB,		0,				0,				0},
	{ TCC7035_CHIP_NUM,		false,		false,	true,	1,			SIZE_1MB,		OFFSET_1MB,		0,				0},
	{ TCC7035_CHIP_NUM,		true,		false,	true,	0,			SIZE_1MB,		0,				0,				0},
	{ TCC7035_CHIP_NUM,		true,		false,	true,	1,			SIZE_1MB,		OFFSET_1MB,		0,				0},

	{ TCC7035_SE_CHIP_NUM,		false,		true,	false,	0,			SIZE_2MB,		0,				0,				0},
	{ TCC7035_SE_CHIP_NUM,		true,		true,	false,	0,			SIZE_2MB,		0,				SIZE_1MB,		0},
	{ TCC7035_SE_CHIP_NUM,		false,		true,	true,	0,			SIZE_1MB,		0,				0,				0},
	{ TCC7035_SE_CHIP_NUM,		false,		true,	true,	1,			SIZE_1MB,		OFFSET_1MB,		0,				0},
	{ TCC7035_SE_CHIP_NUM,		true,		true,	true,	0,			SIZE_1MB,		0,				0,				0},
	{ TCC7035_SE_CHIP_NUM,		true,		true,	true,	1,			SIZE_1MB,		OFFSET_1MB,		0,				0},

	/*{ TCC7035_SE_CHIP_NUM,	false,		true,	false,	0,			SIZE_2MB,		0,				0,				0},
	{ TCC7035_SE_CHIP_NUM,	true,		true,	false,	0,			SIZE_2MB,		0,				SIZE_1MB,		0},
	{ TCC7035_SE_CHIP_NUM,	false,		true,	true,	0,			SIZE_1MB,		0,				0,				0},
	{ TCC7035_SE_CHIP_NUM,	false,		true,	true,	1,			SIZE_1MB,		OFFSET_1MB,		0,				0},
	{ TCC7035_SE_CHIP_NUM,	true,		true,	true,	0,			SIZE_1MB,		0,				0,				0},
	{ TCC7035_SE_CHIP_NUM,	true,		true,	true,	1,			SIZE_1MB,		OFFSET_1MB,		0,				0},*/

	{ TCC7045_CHIP_NUM,		false,		false,	false,	0,			SIZE_2MB,		0,				0,				0},
	{ TCC7045_CHIP_NUM,		true,		false,	false,	0,			SIZE_2MB,		0,				SIZE_2MB,		0},
	{ TCC7045_CHIP_NUM,		false,		false,	true,	0,			SIZE_1MB,		0,				0,				0},
	{ TCC7045_CHIP_NUM,		false,		false,	true,	1,			SIZE_1MB,		OFFSET_1MB,		0,				0},
	{ TCC7045_CHIP_NUM,		true,		false,	true,	0,			SIZE_2MB,		0,				0,				0},
	{ TCC7045_CHIP_NUM,		true,		false,	true,	1,			0,				0,				SIZE_2MB,		0},

	{ TCC7045_SE_CHIP_NUM,		false,		true,	false,	0,			SIZE_2MB,		0,				0,				0},
	{ TCC7045_SE_CHIP_NUM,		true,		true,	false,	0,			SIZE_2MB,		0,				SIZE_2MB,		0},
	{ TCC7045_SE_CHIP_NUM,		false,		true,	true,	0,			SIZE_1MB,		0,				0,				0},
	{ TCC7045_SE_CHIP_NUM,		false,		true,	true,	1,			SIZE_1MB,		OFFSET_1MB,		0,				0},
	{ TCC7045_SE_CHIP_NUM,		true,		true,	true,	0,			SIZE_2MB,		0,				0,				0},
	{ TCC7045_SE_CHIP_NUM,		true,		true,	true,	2,			0,				0,				SIZE_2MB,		0},

	/*{ TCC7045_SE_CHIP_NUM,	false,		true,	false,	0,			SIZE_2MB,		0,				0,				0},
	{ TCC7045_SE_CHIP_NUM,	true,		true,	false,	0,			SIZE_2MB,		0,				SIZE_1780KB,	0},
	{ TCC7045_SE_CHIP_NUM,	false,		true,	true,	0,			SIZE_1MB,		0,				0,				0},
	{ TCC7045_SE_CHIP_NUM,	false,		true,	true,	1,			SIZE_1MB,		OFFSET_1MB,		0,				0},
	{ TCC7045_SE_CHIP_NUM,	true,		true,	true,	0,			SIZE_1780KB,	0,				0,				0},
	{ TCC7045_SE_CHIP_NUM,	true,		true,	true,	1,			0,				0,				SIZE_1780KB,	0},*/
};

class FWDNStorage {
public:
	static bool GetBankInfo(unsigned int uiBankNum, const vcp_chip_info &chipInfo, vcp_bank_info *pBankInfo);

	//for test
	static void PrintChipBanklist();
};
