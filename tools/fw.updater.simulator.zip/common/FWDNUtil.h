#pragma once

#include "config.h"
#ifdef WINDOWS
#include <windows.h>
#include <TlHelp32.h>
#endif

#include <vector>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include "FWDNParseArgs.h"
#include "FWDNParamsVCP.h"
#include "FWDNLogger.h"
#include "FWDNProgressBar.h"
#include "FWDNFile.h"
#include "protocol/FwdnProtocol.h"

#ifdef WINDOWS
#define FWDNSleep(milliSeconds)	Sleep(milliSeconds)
#define FWDNStrtoull(string, endPtr, radix) _strtoui64(string, endPtr, radix)
#else //LINUX
#define FWDNSleep(milliSeconds) usleep(milliSeconds * 1000)
#define FWDNStrtoull(string, endPtr, radix) strtoull(string, endPtr, radix)
#endif

char* mallocString(const char *pString);
bool convertHexStrToUi(const char* pStr, unsigned int * ui);
bool convertHexStrToUll(const char* pStr, unsigned long long * ull);
void GetAddrStrFromUll(unsigned long long ullAddr, char* strAddr);
unsigned int CalcCRC32(char *pBase, unsigned long long ullLen, unsigned int uiCrcIn);
unsigned long long SectorToByte(unsigned long long ullSector, unsigned long long ullSectorSize = FWDN_EMMC_SECTOR_SIZE);
bool CompareCRC(unsigned int uiReceivedCRC, unsigned int uiCalcCRC);
void Upline();
void EraseLine();

unsigned int StrToUintStorageType(char* strStorage);

//related file
bool CompareFileExtension(char* pFileName, const char* pCmpExt);
bool CheckCRCInFile(FWDNFile* pFile, unsigned long long ullFileSize, unsigned int uiReceivedCRC);
unsigned int CalcCRCInFile(char *pFileName);
unsigned int CalcCRCInFile(FWDNFile* pFile, unsigned long long ullFileSize);
unsigned int CalcCRCInFile(FWDNFile* pFile, unsigned long long ullOffset, unsigned long long ullSize);
bool CheckFile(const char* pFileName, unsigned long long ullVaildFileSize = 0);
bool CheckMandatoryFilesVCP(FWDNArgs* pFwdnArgs);

//used in FWDNJsonParser
void GetFilePath(const char* pFileName, char* ret);
unsigned long long GetFileSize(FILE* pFile);