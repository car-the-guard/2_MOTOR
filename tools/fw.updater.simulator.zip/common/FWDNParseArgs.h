#pragma once

#include "config.h"

#include <stdio.h>
#include <ctype.h>
#include "FWDNParamsVCP.h"

struct FWDNArgs {
	char *pWriteFileName;
	char *pReadFileName;
	char *pStorage;
	char *pArea;
	char *pPartitionName;

	char *pHSMFileName;
	char *pFWDNRomFileName;

	unsigned long long ullAddr;
	unsigned long long ullSize;
	unsigned long long ullSectorSize;

	bool bLowFormat;
	bool bDeviceInfo;
	bool bDebugMode;
	bool bSaveLog;
	bool bSpeed;
	bool bTimeStamp;

	unsigned int uiPort;
	unsigned int uiBank;

	FWDNArgs() {
		init();
	}

	void init() {
		pWriteFileName = NULL;
		pReadFileName = NULL;
		pStorage = NULL;
		pPartitionName = NULL;
		bDeviceInfo = false;

		pHSMFileName = NULL;
		pFWDNRomFileName = NULL;

		pArea = NULL;

		ullAddr = 0ULL;
		ullSize = 0ULL;
		ullSectorSize = FWDN_EMMC_SECTOR_SIZE;

		bLowFormat = false;
		bDebugMode = false;
		bSaveLog = false;
		bSpeed = false;
		bTimeStamp = false;

		uiPort = 0U;
		uiBank = 0U;
	}
};

bool CheckLongOptions(int argc, char *argv[]);
bool ParseArgs(int argc, char *argv[], FWDNArgs* param);
bool CheckStorageOption(FWDNArgs* pFwdnArgs);
void PrintHelpMsg(void);
