#pragma once

/*
Interface for USB Driver Class
*/

#define SIZEOF_VID_PID	4U

class IUSBDriver {
public:
	virtual bool ReadData(char *pBuf, unsigned int size, unsigned int *nBytes) = 0;
	virtual bool SendData(char *pBuf, unsigned int size, unsigned int *nBytes) = 0;
	virtual bool OpenPort() = 0;
	virtual bool ClosePort() = 0;
	virtual unsigned int SetTimeout(unsigned int rwTimeout) = 0;
	virtual bool InitUsbNotification() = 0;
	virtual void WaitUntilUsbConnected() = 0;
	virtual unsigned int GetPID() = 0;
};
