#include "FWDNStorage.h"
#include "FWDNLogger.h"
#include <string>

std::string boolToStr(bool bValue)
{
	return (bValue ? std::string("true") : std::string("false"));
}

bool FWDNStorage::GetBankInfo(unsigned int uiBankNum, const vcp_chip_info &chipInfo, vcp_bank_info *pBankInfo)
{
	if ((pBankInfo == NULL)
		|| (uiBankNum > 1)) {
		//return false;
	}

	for (int i = 0; i < MAX_BANK_INFO; i++) {
		if (chip_bank_info_list[i].chipInfo.uiChipNumber == chipInfo.uiChipNumber
				&& chip_bank_info_list[i].chipInfo.bExpandSnor == chipInfo.bExpandSnor
				//&& chip_bank_info_list[i].chipInfo.bEcc == chipInfo.bEcc
				&& chip_bank_info_list[i].chipInfo.bDualBank == chipInfo.bDualBank
				&& (chip_bank_info_list[i].bankInfo.uiBankNum == uiBankNum)) {
            //memcpy(pBankInfo, &chip_bank_info_list[i+1].bankInfo, sizeof(vcp_bank_info)); //snor
            memcpy(pBankInfo, &chip_bank_info_list[i].bankInfo, sizeof(vcp_bank_info)); //eflash
			return true;
		}
	}

	FWDNMessage(FWDN_RED_MSG,
		"Storage for the chip information below is not defined\n"
		"Chip Number : 0x%x\n"
		"Bank Number : %d\n"
		"Dual Bank : %s\n"
		"Expand Flash : %s\n"
		"ECC : %s\n",
		 chipInfo.uiChipNumber,
		 uiBankNum,
		 boolToStr(chipInfo.bDualBank).c_str(),
		 boolToStr(chipInfo.bExpandSnor).c_str(),
		 boolToStr(chipInfo.bEcc).c_str()
	);

	return false;
}

void FWDNStorage::PrintChipBanklist()
{
	for (int i = 0; i < MAX_BANK_INFO; i++) {
		//Chip number /Exapnd /ecc /dual //bank num /eflash size /eflash offset /snor size /snor offset

		std::cout << chip_bank_info_list[i].chipInfo.uiChipNumber << ",\t"
			<< boolToStr(chip_bank_info_list[i].chipInfo.bExpandSnor) << ",\t"
			<< boolToStr(chip_bank_info_list[i].chipInfo.bEcc) << ",\t"
			<< boolToStr(chip_bank_info_list[i].chipInfo.bDualBank) << ",\t"

			<< chip_bank_info_list[i].bankInfo.uiBankNum << ",\t"
			<< chip_bank_info_list[i].bankInfo.uiEflashSize << ",\t"
			<< chip_bank_info_list[i].bankInfo.uiEflashOffset << ",\t"
			<< chip_bank_info_list[i].bankInfo.uiSnorSize << ",\t"
			<< chip_bank_info_list[i].bankInfo.uiSnorOffset << std::endl;
	}
}