#include "config.h"
#ifdef WINDOWS
#include <windows.h>
#else 	//LINUX
#include <cstring>
#endif

#include "FWDNLogger.h"
#include "FWDNParseArgs.h"
#include "FWDNVersion.h"
#include "FWDN_VCP.h"

#define FWDN_VERSION 000003	// == v00.00.03

#define VCP_FW_BAUDRATE			(921600)
//#define VCP_FW_BAUDRATE				(256000)
//#define VCP_FW_BAUDRATE			(CBR_115200)

#define VCP_CHIP_BOOT_BAUDRATE	(CBR_115200)

int main(int argc, char* argv[])
{
	FWDNVersion::GetIns()->HostVersion(FWDN_VERSION);
	FWDNMessage(FWDN_GREEN_MSG, "FWDN VCP v%s - %s %s\n",
		FWDNVersion::GetIns()->StrHostVersion(),
		FWDNVersion::GetIns()->StrBuildDate(),
		__TIME__);

	FWDNArgs fwdnArgs;
	bool bRes = true;
	CSerialPort serial;
	FWDN_VCP* fwdnVcp = new FWDN_VCP(&serial);

	if(ParseArgs(argc, argv, &fwdnArgs) == false) {
		return -1;
	}

	//Set log option
	FWDNLogger::GetIns()->SetSaveLog(fwdnArgs.bSaveLog);
	FWDNLogger::GetIns()->TimeStamp(fwdnArgs.bTimeStamp);
	FWDNLogger::GetIns()->DebugMode(fwdnArgs.bDebugMode);

	//Set progress bar speed option
 	ProgressBar::GetIns()->SetShowSpeed(fwdnArgs.bSpeed);

	/* Connect serial port */
	char portName[16];

	if (fwdnArgs.uiPort == 0) {
		printf("Com port num : ");
		scanf("%d", &fwdnArgs.uiPort);
	}
	sprintf(portName, "\\\\.\\COM%d", fwdnArgs.uiPort);

	if (serial.OpenPort(portName) == false) {
		return -1;
	}

	//temporary
	//Depending on the FPGA board, it may be necessary to use half the baudrate.
	//example ) 115200 -> 57600
	serial.SetCommunicationTimeouts(10, 10, 10, 10, 10);
	serial.ConfigurePort(VCP_FW_BAUDRATE, 8, FALSE, NOPARITY, ONESTOPBIT);
	if (fwdnVcp->CheckPing() == false) {
		//serial.ConfigurePort(VCP_CHIP_BOOT_BAUDRATE, 8, FALSE, NOPARITY, ONESTOPBIT);
		serial.ConfigurePort(VCP_FW_BAUDRATE, 8, FALSE, NOPARITY, ONESTOPBIT);

		if (CheckMandatoryFilesVCP(&fwdnArgs) == false) {
			FWDNMessage(FWDN_RED_MSG,
				"You need to check mandatory files\n");
			return -1;
		}

	    fwdnVcp->LoadFwdnFW(&fwdnArgs);

		//for tresh data
		serial.SetCommunicationTimeouts(1, 1, 1, 1, 1);
		serial.ReadTreshData(100);
	}

	ProtocolFW fwProtocol(&serial);

	//serial.ConfigurePort(VCP_FW_BAUDRATE, 8, FALSE, NOPARITY, ONESTOPBIT);
	//serial.SetCommunicationTimeouts(0, 0, 0, 0, 0);

	fwdnVcp->GetDeviceVersion();
	//fwdnVcp->InfoStorage();
	fwdnVcp->GetChipInfo();

    fwdnVcp->ReadyToUpdate();

	if(fwdnArgs.bLowFormat == true) {
		if(fwdnVcp->LowformatCommand(/*&fwdnArgs*/) == false) {
			return -1;
		}

		bRes = true;
	}

	if (fwdnArgs.pStorage == NULL) {
		if (fwdnArgs.pWriteFileName != NULL) {
			bRes = fwdnVcp->WriteFileByBank(
				&fwdnArgs, VCP_WRITE_CMD, &fwProtocol);
		}

		if (fwdnArgs.pReadFileName != NULL) {
			bRes = fwdnVcp->DumpStorageByBank(
				&fwdnArgs, VCP_READ_CMD, &fwProtocol);
		}
	} else {
		if (fwdnArgs.pWriteFileName != NULL) {
			bRes = fwdnVcp->WriteFile(
				&fwdnArgs, VCP_WRITE_CMD, &fwProtocol, fwdnArgs.ullAddr);
		}

		if (fwdnArgs.pReadFileName != NULL) {
			bRes = fwdnVcp->DumpStorage(
				&fwdnArgs, VCP_READ_CMD,
				(unsigned int)fwdnArgs.ullSize, "wb");
		}
	}

	if(bRes) {
		FWDNMessage(FWDN_GREEN_MSG,
			"Complete FWDN\n");
	} else {
		FWDNMessage(FWDN_RED_MSG,
			"Failed FWDN\n");
	}

	FWDNLogger::GetIns()->PrintCurTime();
	delete fwdnVcp;
	return 0;
}
