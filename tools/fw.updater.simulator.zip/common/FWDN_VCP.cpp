#include "FWDN_VCP.h"
#include <string>

FWDN_VCP::FWDN_VCP(CSerialPort *serial)
:m_serial(serial)
{
	if (m_serial == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] m_serial == NULL\n");
	}
}

bool FWDN_VCP::CheckPing()
{
	ProtocolFW fw(m_serial);
	bool ret;
	CmdPacket cmd = fw.MakeCmdPacket(VCP_FW_PING, NULL);

	if (fw.SendCommand(&cmd)
			== false) {
		return false;
	} else {
		ret = fw.RecvResponse(
			VCP_FW_PING, NULL, 100);
	}

	return ret;
}

bool FWDN_VCP::InfoStorage()
{
	ProtocolFW fw(m_serial);
	CmdPacket res;
	char *buf;
	unsigned long ulResultSize;
	CmdPacket cmd = fw.MakeCmdPacket(VCP_STORAGE_INFO_CMD, NULL);

	if (fw.SendCommand(&cmd)
			== false) {
		return false;
	} else if(fw.RecvResponse(VCP_STORAGE_INFO_CMD, &res)
			== false) {
		return false;
	}

	buf = (char *)malloc(res.uiParam1 + 1);
	if (buf == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] Failed to malloc - (buf == NULL)\n");
		return false;
	}

	//print storage info
	memset(buf, 0, res.uiParam1 + 1);
	m_serial->ReadData(buf, res.uiParam1, &ulResultSize);
	FWDNMessage(FWDN_BLUE_MSG, "\n%s\n", buf);
	free(buf);

	return true;
}

bool FWDN_VCP::GetDeviceVersion()
{
	ProtocolFW fw(m_serial);
	CmdPacket res;
	unsigned long ulResultSize;
	CmdPacket cmd = fw.MakeCmdPacket(VCP_VERSION_CMD, NULL);

	if (fw.SendCommand(&cmd)
			== false) {
		return false;
	} else if(fw.RecvResponse(VCP_VERSION_CMD, &res)
			== false) {
		return false;
	}

	FWDNMessage(FWDN_BLUE_MSG, " FWDN Firmware Version(%d)\n", res.uiParam1);

	return true;
}

std::string BoolToStr(bool bValue)
{
	return (bValue ? std::string("true") : std::string("false"));
}

bool FWDN_VCP::GetChipInfo()
{
	ProtocolFW fw(m_serial);
	CmdPacket res;
	CmdPacket cmd = fw.MakeCmdPacket(VCP_CHIP_INFO_CMD, NULL);

	if (fw.SendCommand(&cmd)
			== false) {
		return false;
	} else if(fw.RecvResponse(VCP_CHIP_INFO_CMD, &res)
			== false) {
		return false;
	}

	if(fw.RecvData((char *)&res, fw.PacketSize())
			== false) {
		return false;
	}

	m_vcpChipInfo.bDualBank = res.uiParam0 ? true : false;
	m_vcpChipInfo.bExpandSnor = res.uiParam1 ? true : false;
	m_vcpChipInfo.uiChipNumber = res.uiParam2;
	//m_vcpChipInfo.bEcc = res.uiParam3 ? true : false;
	m_vcpBankInfo.uiBankNum = res.uiParam3;

	FWDNMessage(FWDN_BLUE_MSG,
		"---chip info---\n"
		"Chip Number : 0x%x\n"
		"Dual Bank : %s\n"
		"Expand Flash : %s\n"
		"ECC : %s\n",
		 m_vcpChipInfo.uiChipNumber,
		 BoolToStr(m_vcpChipInfo.bDualBank).c_str(),
		 BoolToStr(m_vcpChipInfo.bExpandSnor).c_str(),
		 BoolToStr(m_vcpChipInfo.bEcc).c_str()
	);

	return true;
}

bool FWDN_VCP::ReadyToUpdate()
{
	ProtocolFW fw(m_serial);
	CmdPacket res;
	unsigned long ulResultSize;
	CmdPacket cmd = fw.MakeCmdPacket(VCP_READY_CMD, NULL);

	if (fw.SendCommand(&cmd)
			== false) {
		return false;
	} else if(fw.RecvResponse(VCP_READY_CMD, &res)
			== false) {
		return false;
	}

	FWDNMessage(FWDN_BLUE_MSG, " FWDN Ready To Update \n");

	return true;
}

bool FWDN_VCP::LoadFwdnFW(FWDNArgs *pFwdnArgs)
{
	bool bRes = false;
	ProtocolCB chipboot(m_serial);
	FWDNArgs fwdnArgs;

	if (pFwdnArgs == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[Error] fwdnArgs == NULL\n");
		return false;
	}

	while (bRes == false) {
		if (chipboot.StartVCPFWDN() == false) {
			FWDNSleep(100);
			continue;
		} else {
			FWDNMessage(FWDN_BLUE_MSG,
				"Complete to send start msg\n");
		}

        bRes = true;

		m_serial->SetCommunicationTimeouts(100, 100, 100, 100, 100);
		FWDNSleep(50);	//for stability

#if 0 //block - BSKim
		//Send HSM
		if (pFwdnArgs->pHSMFileName == NULL) {
			fwdnArgs.pWriteFileName = pFwdnArgs->pWriteFileName;
		} else {
			fwdnArgs.pWriteFileName = pFwdnArgs->pHSMFileName;
		}
		fwdnArgs.ullSize = HSM_SIZE;
		fwdnArgs.ullAddr = HSM_OFFSET;
		bRes = WriteFile(&fwdnArgs, VCP_RECEIVE_HSM_CMD, &chipboot, fwdnArgs.ullAddr);
		if (bRes == false) {
			continue;
		}
		FWDNMessage(FWDN_BLUE_MSG,
			"Complete to send hsm\n");

		FWDNSleep(50);	//for stability

		//Send FWDN F/W
		memset(&fwdnArgs, 0, sizeof(FWDNArgs));
		fwdnArgs.pWriteFileName = pFwdnArgs->pFWDNRomFileName;
		bRes = WriteFile(&fwdnArgs, VCP_RECEIVE_FWDN_CMD, &chipboot, fwdnArgs.ullAddr);
		if (bRes == true) {
			FWDNMessage(FWDN_BLUE_MSG,
				"Complete to send fwdn\n");
			break;
		}
#endif
	}

	FWDNMessage(FWDN_GREEN_MSG,
		"Complete to load FWDN F/W\n");

	return true;
}

bool FWDN_VCP::WriteFileByBank(FWDNArgs *pFwdnArgs, unsigned int uiCmd, FwdnProtocol *pProtocol)
{
	vcp_bank_info bankInfo;
	bool bRet = false;
	FWDNFile file(pFwdnArgs->pWriteFileName, "rb");
	unsigned int uiFileSize = file.GetSize();
	unsigned int uiRemainSize = uiFileSize;
	unsigned long long ullFileAddr = 0;

	if (pProtocol == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] pProtocol == NULL\n");
		return false;
	}

	//if (FWDNStorage::GetBankInfo(pFwdnArgs->uiBank, m_vcpChipInfo, &bankInfo)
	if (FWDNStorage::GetBankInfo(m_vcpBankInfo.uiBankNum, m_vcpChipInfo, &bankInfo)
			== false) {
		return false;
	}

	PrintBankInfo(*pFwdnArgs, bankInfo);

	if (uiFileSize > bankInfo.uiEflashSize + bankInfo.uiSnorSize) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] File size(%u) > Storage size(%u)\n",
			uiFileSize, bankInfo.uiEflashSize + bankInfo.uiSnorSize);
		return false;
	}

	if ((bankInfo.uiEflashSize != 0) && (uiRemainSize > 0)) {
		pFwdnArgs->pStorage = "eflash";
		pFwdnArgs->ullAddr = bankInfo.uiEflashOffset;
		pFwdnArgs->ullSize = (bankInfo.uiEflashSize > uiFileSize ?
								uiFileSize : bankInfo.uiEflashSize);

		uiRemainSize -= pFwdnArgs->ullSize;

		PrintStorageOption(*pFwdnArgs);
		bRet = WriteFile(pFwdnArgs, uiCmd, pProtocol, pFwdnArgs->ullAddr);
		if (bRet == false) {
			FWDNMessage(FWDN_RED_MSG, "Failed to write in eFlash\n");
			return false;
		}
	}

	if ((bankInfo.uiSnorSize != 0) && (uiRemainSize > 0)) {
		pFwdnArgs->pStorage = "snor";
		ullFileAddr = pFwdnArgs->ullSize;
		pFwdnArgs->ullAddr = bankInfo.uiSnorOffset;
		pFwdnArgs->ullSize = uiFileSize - bankInfo.uiEflashSize;

		PrintStorageOption(*pFwdnArgs);
		bRet = WriteFile(pFwdnArgs, uiCmd, pProtocol, ullFileAddr);
		if (bRet == false) {
			FWDNMessage(FWDN_RED_MSG, "Failed to write in SNOR\n");
			return false;
		}
	}

	return bRet;
}

bool FWDN_VCP::WriteFile(
	FWDNArgs *pFwdnArgs, unsigned int uiCmd, FwdnProtocol *pProtocol, unsigned long long ullFileAddr)
{
	CmdPacket cmd;
	CmdPacket res;
	char *pFileName = pFwdnArgs->pWriteFileName;
	FWDNFile file(pFileName, "rb");

	if (pProtocol == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] pProtocol == NULL\n");
		return false;
	}

	if (pFileName == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] pFileName == NULL\n");
		return false;
	}

	cmd = pProtocol->MakeCmdPacket(uiCmd, pFwdnArgs);

	if (pProtocol->SendCommand(&cmd)
			== false) {
		return false;
	} else if (pProtocol->RecvResponse(uiCmd, &res, 0)
			== false) {
		return false;
	} else {
		std::string str;

		pProtocol->GetDefineStr(uiCmd, &str);
		FWDNMessage(FWDN_WHITE_MSG,
			"Complete to send command(0x%X(%s))\n", uiCmd, str.c_str());
	}

	FWDNSleep(50);	//for stability

	if (pProtocol->SendFileAndRecvRes(
			pFileName, uiCmd, ullFileAddr, pFwdnArgs->ullSize)
			== false) {
		return false;
	} else {
		FWDNMessage(FWDN_GREEN_MSG,
			"Complete to send file - %s\n", pFileName);
	}
	FWDNSleep(50);	//for stability

	return true;
}


bool FWDN_VCP::DumpStorageByBank(FWDNArgs *pFwdnArgs, unsigned int uiCmd, FwdnProtocol *pProtocol)
{
	vcp_bank_info bankInfo;
	bool bRet = false;
	FWDNFile file(pFwdnArgs->pWriteFileName, "rb");
	unsigned int uiFileSize = file.GetSize();

	if (pProtocol == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] pProtocol == NULL\n");
		return false;
	}

	if (FWDNStorage::GetBankInfo(pFwdnArgs->uiBank, m_vcpChipInfo, &bankInfo)
			== false) {
		return false;
	}

	PrintBankInfo(*pFwdnArgs, bankInfo);

	if (bankInfo.uiEflashSize != 0) {
		pFwdnArgs->pStorage = "eflash";
		pFwdnArgs->ullAddr = bankInfo.uiEflashOffset;
		pFwdnArgs->ullSize = bankInfo.uiEflashSize;

		PrintStorageOption(*pFwdnArgs);

		bRet = DumpStorage(
				pFwdnArgs, VCP_READ_CMD,
				(unsigned int)pFwdnArgs->ullSize, "wb");
		if (bRet == false) {
			FWDNMessage(FWDN_RED_MSG, "Failed to write in eFlash\n");
			return false;
		}
	}

	if (bankInfo.uiSnorSize != 0) {
		pFwdnArgs->pStorage = "snor";
		pFwdnArgs->ullAddr = bankInfo.uiSnorOffset;
		pFwdnArgs->ullSize = bankInfo.uiSnorSize;

		PrintStorageOption(*pFwdnArgs);

		if (bankInfo.uiEflashSize == 0) {
			bRet = DumpStorage(
				pFwdnArgs, VCP_READ_CMD,
				(unsigned int)pFwdnArgs->ullSize, "wb");
		} else {
			bRet = DumpStorage(
				pFwdnArgs, VCP_READ_CMD,
				(unsigned int)pFwdnArgs->ullSize, "ab");
		}

		if (bRet == false) {
			FWDNMessage(FWDN_RED_MSG, "Failed to write in SNOR\n");
			return false;
		}
	}

	return bRet;
}

bool FWDN_VCP::DumpStorage(
	FWDNArgs *pFwdnArgs, unsigned int uiCmd,
	unsigned int uiRequestSize, char *strFileOption)
{
	char *pFileName = pFwdnArgs->pReadFileName;
	ProtocolFW fw(m_serial);

	if (pFileName == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] pFileName == NULL\n");
		return false;
	}

	CmdPacket cmd = fw.MakeCmdPacket(uiCmd, pFwdnArgs);

	if (fw.SendCommand(&cmd)
			== false) {
		return false;
	} else if(fw.RecvResponse(uiCmd, NULL)
			== false) {
		return false;
	} else {
		FWDNMessage(FWDN_WHITE_MSG,
			"Complete to send command - %s\n", pFileName);
	}

	FWDNSleep(50);	//for stability

	FWDNFile file(pFileName, strFileOption);

	if (fw.DumpProtocol(file, uiCmd, uiRequestSize)
			== false) {
		return false;
	} else {
		FWDNMessage(FWDN_WHITE_MSG,
			"Complete to receive file - %s\n", pFileName);
	}

	FWDNSleep(50);	//for stability
	return true;
}

bool FWDN_VCP::LowformatCommand()
{
	ProtocolFW fw(m_serial);
	CmdPacket cmd = fw.MakeCmdPacket(VCP_LOW_FORMAT_CMD, NULL);

	FWDNMessage(FWDN_GREEN_MSG, "Start to low format\n");

	if (fw.SendCommand(&cmd)
			== false) {
		return false;
	} else if(fw.RecvResponse(VCP_LOW_FORMAT_CMD, NULL)
			== false) {
		return false;
	}

	FWDNMessage(FWDN_WHITE_MSG,
		"Complete to send low format command\n");

	FWDNMessage(FWDN_BLUE_MSG,
			"Please wait, low-format can take a long time!\n");

	if(fw.RecvResponse(VCP_LOW_FORMAT_CMD, NULL)
			== false) {
		return false;
	}

	FWDNMessage(FWDN_WHITE_MSG,
		"Complete to low format\n");

	return true;
}

void FWDN_VCP::PrintStorageOption(FWDNArgs &fwdnArgs)
{
	FWDNMessage(FWDN_BLUE_MSG,
		"---storage info---\n"
		"%s\n"
		"offset : 0x%x\n"
		"size : %u byte\n",
		fwdnArgs.pStorage,
		(unsigned int)(fwdnArgs.ullAddr & MASK_OF_32BITS),
		(unsigned int)(fwdnArgs.ullSize)
	);
}

void FWDN_VCP::PrintBankInfo(FWDNArgs &fwdnArgs, vcp_bank_info &bankInfo)
{
	FWDNMessage(FWDN_BLUE_MSG,
		"---bank info---\n"
		"bank - %d\n"
		"eFlash offset : 0x%x\n"
		"eFlash size : %u byte\n"
		"SNOR offset : 0x%x\n"
		"SNOR size : %u byte\n",
		fwdnArgs.uiBank,
		bankInfo.uiEflashOffset,
		bankInfo.uiEflashSize,
		bankInfo.uiSnorOffset,
		bankInfo.uiSnorSize
	);
}
