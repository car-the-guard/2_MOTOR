#include "FWDNUtil.h"
#include "FWDNFile.h"
#include <stdlib.h>

bool convertHexStrToUll(const char* pStr, unsigned long long * ull)
{
	unsigned long long hex = (unsigned long long)FWDNStrtoull(pStr, NULL, 16);	//string to hex
	unsigned long long dec = (unsigned long long)FWDNStrtoull(pStr, NULL, 0);	//string to dec

	if(dec != hex && dec == 0) {
		printf("%s is invalid value\n", pStr);
		return false;
	} else {
		*ull = dec;
		return true;
	}
}

bool convertHexStrToUi(const char* pStr, unsigned int * ui)
{
	unsigned int hex = (unsigned int)strtoul(pStr, NULL, 16);	//string to hex
	unsigned int dec = (unsigned int)strtoul(pStr, NULL, 0);	//string to dec

	if(dec != hex && dec == 0) {
		printf("%s is invalid value\n", pStr);
		return false;
	} else {
		*ui = dec;
		return true;
	}
}

unsigned int CalcCRC32(char *pBase, unsigned long long ullLen, unsigned int uiCrcIn)
{
	unsigned long long cnt;
	unsigned char code;

	for(cnt = 0; cnt < ullLen; cnt++) {
		code = (unsigned char)(pBase[cnt] ^ uiCrcIn);
		uiCrcIn = (uiCrcIn >> 8) ^ CRC32_TABLE[code & 0xFF];
	}

	return uiCrcIn;
}

void Upline()
{
#ifdef WINDOWS
	COORD pos;
	CONSOLE_SCREEN_BUFFER_INFO info;
	HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);
	GetConsoleScreenBufferInfo(handle, &info);
	pos.X = 0;
	pos.Y = info.dwCursorPosition.Y - 1;
	SetConsoleCursorPosition(handle, pos);
#else
	printf("\033[1A");
#endif
}

void EraseLine()
{
	printf("\033[2K");
	printf("\r");
#ifdef WINDOWS
	HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE); \
	CONSOLE_SCREEN_BUFFER_INFO info;

	// initialize
	GetConsoleScreenBufferInfo(handle, &info);

	COORD origin = {0,info.dwCursorPosition.Y}; //warning C4204
	SHORT cnt;
	DWORD tmp;

	cnt = info.dwSize.X;

	FillConsoleOutputAttribute(handle, info.wAttributes, cnt, origin, &tmp);
	FillConsoleOutputCharacter(handle, ' ', cnt, origin, &tmp);
#endif
}

unsigned int CalcCRCInFile(char *pFileName)
{
	DEBUG_FWDNMessage(FWDN_BLUE_MSG, "Start to calcuate CRC\n");

	FWDNFile file;
	unsigned int uiCRC;

	if (pFileName == NULL) {
		FWDNMessage(FWDN_RED_MSG, "[ERROR] pFileName == NULL\n");
		return 0;
	}

	file.Open(pFileName, "rb");
	uiCRC = CalcCRCInFile(&file, file.GetSize());
	return uiCRC;
}

unsigned int CalcCRCInFile(FWDNFile* pFile, unsigned long long ullSize)
{
	return CalcCRCInFile(pFile, 0, ullSize);
}

unsigned int CalcCRCInFile(FWDNFile* pFile, unsigned long long ullOffset, unsigned long long ullSize)
{
	DEBUG_FWDNMessage(FWDN_BLUE_MSG, "Start to calcuate CRC\n");

	bool bRes = true;
	unsigned long long ullRemainSize = ullSize;
	unsigned long long ullBunch;
	unsigned int uiCRC = 0;
	char* pFileBuffer;

	if (pFile == NULL) {
		FWDNMessage(FWDN_RED_MSG, "[ERROR] pFile == NULL\n");
		return 0;
	}

	pFile->SetOffset(ullOffset, SEEK_SET);

	if (ullRemainSize == 0) {
		ullRemainSize = pFile->GetSize() - ullOffset;
	}

	while(ullRemainSize != 0) {
		if(ullRemainSize >= USB_MAX_TRANSFER_BUFFER_SIZE) {
			ullBunch = USB_MAX_TRANSFER_BUFFER_SIZE;
			ullRemainSize -= USB_MAX_TRANSFER_BUFFER_SIZE;
		} else {
			ullBunch = ullRemainSize;
			ullRemainSize = 0;
		}

		pFileBuffer = pFile->Read(ullBunch);
		uiCRC = CalcCRC32(pFileBuffer, ullBunch, uiCRC);
	}

	return uiCRC;
}

bool CheckCRCInFile(FWDNFile* pFile, unsigned long long ullFileSize, unsigned int uiReceivedCRC)
{
	DEBUG_FWDNMessage(FWDN_BLUE_MSG, "Start to check CRC\n");

	bool bRes = true;
	unsigned long long ullRemainSize = ullFileSize;
	unsigned long long ullBunch;
	unsigned int uiCRC = 0;
	char* pFileBuffer;

	char acProgress[4] = {'\\', '|', '/', '-'};
	int iProgress = 0;

	if (pFile == NULL) {
		FWDNMessage(FWDN_RED_MSG, "[ERROR] pFile == NULL\n");
		return 0;
	}

	printf("\n");

	while(ullRemainSize != 0) {
		if(ullRemainSize >= USB_MAX_TRANSFER_BUFFER_SIZE) {
			ullBunch = USB_MAX_TRANSFER_BUFFER_SIZE;
			ullRemainSize -= USB_MAX_TRANSFER_BUFFER_SIZE;
		} else {
			ullBunch = ullRemainSize;
			ullRemainSize = 0;
		}

		pFileBuffer = pFile->Read(ullBunch);
		uiCRC = CalcCRC32(pFileBuffer, ullBunch, uiCRC);

		iProgress = (++iProgress) % 4;
		printf("\rCheck CRC %c", acProgress[iProgress]);
	}

	EraseLine();
	Upline();

	bRes = CompareCRC(uiReceivedCRC, uiCRC);

	if(bRes == true) {
		DEBUG_FWDNMessage(FWDN_BLUE_MSG, "Complete to check CRC\n");
	} else {
		FWDNMessage(FWDN_BLUE_MSG, "Failed to check CRC\n");
	}

	return bRes;
}

unsigned int StrToUintStorageType(char* strStorage)
{
	if(strStorage == NULL) {
		return 0;
	}

	if(strncmp(strStorage,
			FWDN_SNOR_STR, sizeof(FWDN_SNOR_STR)) == 0) {
		return VCP_SNOR;
	} else if(strncmp(strStorage,
			FWDN_EFLASH_STR, sizeof(FWDN_EFLASH_STR)) == 0) {
		return VCP_EFLASH;
	} else {
		FWDNMessage(FWDN_RED_MSG,
			"\"%s\" is invalid storage type\n", strStorage);
		return 0;
	}

	return 0;
}

char* mallocString(const char *pString)
{
	char *ret = NULL;
	unsigned int len = 0;

	if(pString) {
		len = strlen(pString);
		ret = (char*)malloc((len * sizeof(char)) + sizeof(char));
		if (ret) {
			strcpy(ret, pString);
		}
	}
	return ret;
}

bool CompareFileExtension(char* pFileName, const char* pCmpExt)
{
	size_t len = strlen(pFileName);
	char* pFileExt = NULL;
	pFileName += len;

	for(size_t i = 0 ; i < len ; i++) {
		if(*pFileName == '.' ) {
			pFileExt = pFileName + 1 ;
			break;
		}
		pFileName--;
	}

	if(pFileExt != NULL) {
		len = strlen(pFileExt);
		if(strncmp(pFileExt, pCmpExt, len) == 0){
			return true;
		}
	}

	return false;
}

void GetFilePath(const char* pFileName, char* ret)
{
	char fullPathName[260];
#ifdef WINDOWS
	GetFullPathName(pFileName, MAX_PATH, fullPathName, NULL);
#else
	realpath(pFileName, fullPathName);
#endif
	int len = strlen(fullPathName);
	for(int i = len; i > 0; i--) {
		if(fullPathName[i] == '/' || fullPathName[i] == '\\') {
			strncpy(ret, fullPathName, i);
			ret[i] = FILE_PATH_TOKEN;
			ret[i + 1] = '\0';
			break;
		}
	}
}

char* GetFileNameFromFilePath(char* pFilePath)
{
	char *pFileName = NULL;

	while(*pFilePath) {
		if(*pFilePath == FILE_PATH_TOKEN && (pFilePath + 1) != NULL){
			pFileName = pFilePath + 1;
		}

		pFilePath++;
	}

	return pFileName;
}

unsigned long long GetFileSize(FILE* pFile)
{
	unsigned long long ullFileSize = 0;
	if(pFile != NULL) {
		fseek(pFile, 0, SEEK_END);
		ullFileSize = FWDNFtello64(pFile);
		rewind(pFile);
	}

	return ullFileSize;
}

void GetAddrStrFromUll(unsigned long long ullAddr, char* strAddr)
{
	sprintf(strAddr, "0x");
	if(ullAddr >> 32ULL != 0) {		//64bit address
		sprintf(strAddr + 2, "%.8X", ullAddr >> 32ULL);
		strAddr[10] = ' ';
		sprintf(strAddr + 11, "%.8X", ullAddr & 0xffffffffULL);
		strAddr[19] = '\0';
	} else {
		sprintf(strAddr + 2, "%.8X", ullAddr & 0xffffffffULL);
		strAddr[10] = '\0';
	}
}

bool CompareCRC(unsigned int uiReceivedCRC, unsigned int uiCalcCRC)
{
	if(uiCalcCRC == uiReceivedCRC) {
		DEBUG_FWDNMessage(FWDN_BLUE_MSG,
			"Succeeded to check CRC (received crc = %#x, calc crc = %#x)\n", uiReceivedCRC, uiCalcCRC);
		return true;
	} else {
		FWDNMessage(FWDN_RED_MSG,
			"CRC values are different (received crc = %#x, calc crc = %#x)\n", uiReceivedCRC, uiCalcCRC);
		return false;
	}
}

unsigned long long SectorToByte(unsigned long long ullSector, unsigned long long ullSectorSize)
{
	return ullSector * ullSectorSize;
}

unsigned long long GetPercent(unsigned long long ullSize, unsigned long long ullTotalSize)
{
	if(ullTotalSize == 0) {
		FWDNMessage(FWDN_RED_MSG, "ullTotalSize(%llu) is invalid value\n", ullTotalSize);
		return 0;
	}
	return (unsigned long long)((ullSize * 100ULL) / ullTotalSize);
}

bool CheckMandatoryFilesVCP(FWDNArgs* pFwdnArgs)
{
	DEBUG_FWDNMessage(FWDN_WHITE_MSG, "Start to check mandatory files\n");

/*
	//Check fwdn rom
	if(CheckFile(pFwdnArgs->pFWDNRomFileName) == false) {
		FWDNMessage(FWDN_RED_MSG, "Failed to check file - %s\n", pFwdnArgs->pFWDNRomFileName);
		return false;
	}
*/

	if(pFwdnArgs->pWriteFileName == NULL) {
		if(CheckFile(pFwdnArgs->pHSMFileName) == false) {
			FWDNMessage(FWDN_RED_MSG, "Failed to check file - %s\n", pFwdnArgs->pHSMFileName);
			return false;
		}
	}

	DEBUG_FWDNMessage(FWDN_WHITE_MSG, "Complete to check mandatory files\n");
	return true;
}

bool CheckFile(const char* pFileName, unsigned long long ullVaildFileSize)
{
	DEBUG_FWDNMessage(FWDN_WHITE_MSG, "Start to check file - %s\n", pFileName);

	FWDNFile file;

	if(file.Open(pFileName, "rb") == false) {
		FWDNMessage(FWDN_RED_MSG, "Failed to open file - %s\n", pFileName);
		return false;
	} else if(ullVaildFileSize != 0) {
		unsigned long long ullFileSize = file.GetSize();

		if(ullFileSize != ullVaildFileSize) {
			FWDNMessage(FWDN_RED_MSG,
				"valid size(%llu) and actual file size%llu are different\n"
				, ullVaildFileSize, ullFileSize);
			return false;
		}
	}

	DEBUG_FWDNMessage(FWDN_WHITE_MSG,
		"Complete to check file - %s\n", pFileName);
	return true;
}