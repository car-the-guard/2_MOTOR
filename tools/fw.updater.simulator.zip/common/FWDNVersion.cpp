#include "FWDNVersion.h"
#include <stdio.h>
#include <string.h>

FWDNVersion* FWDNVersion::m_pFWDNVersion = NULL;

FWDNVersion* FWDNVersion::GetIns(){
	if (m_pFWDNVersion == NULL) {
		m_pFWDNVersion = new FWDNVersion;
	}
	return m_pFWDNVersion;
}

FWDNVersion::FWDNVersion():
m_uiHostVersion(0),
m_uiFWVersion(0)
{
	memset(m_strHostVersion, 0, VersionMaxLength);
	memset(m_strFWVersion, 0, VersionMaxLength);
	memset(m_strBuildDate, 0, BuildDateMaxLength);
	GetBuildDate();
}

void FWDNVersion::FWVersion(unsigned int version)
{
	m_uiFWVersion = version;
	VersionUintToStr(m_strFWVersion, m_uiFWVersion);
}

void FWDNVersion::HostVersion(unsigned int version)
{
	m_uiHostVersion = version;
	VersionUintToStr(m_strHostVersion, m_uiHostVersion);
}

unsigned int FWDNVersion::FWVersion()
{
	return m_uiFWVersion;
}

unsigned int FWDNVersion::HostVersion()
{
	return m_uiHostVersion;
}

char* FWDNVersion::StrHostVersion()
{
	return m_strHostVersion;
}
char* FWDNVersion::StrFWVersion()
{
	return m_strFWVersion;
}

char* FWDNVersion::StrBuildDate()
{
	return m_strBuildDate;
}

void FWDNVersion::VersionUintToStr(char* str, unsigned int uint)
{
	sprintf(str, "%d.%d.%d",
		(uint / 10000) % 100, (uint / 100) % 100, (uint) % 100);
}

void FWDNVersion::GetBuildDate()
{
	const char *MONTHS[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun",
							"Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
	const char *strDate = __DATE__;

	m_uiYear = (unsigned int)strtoul(strDate + 7, NULL, 10);
	m_uiDay = (unsigned int)strtoul(strDate + 4, NULL, 10);
	for(int i = 0; i < 12; i++) {
		if(strncmp(strDate, MONTHS[i], 3) == 0) {
			m_uiMonth = i + 1;
			break;
		}
	}

	sprintf(m_strBuildDate, "%d.%d.%d", m_uiYear, m_uiMonth, m_uiDay);
}