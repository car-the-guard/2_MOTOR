#include "FWDNLogger.h"
#include "FWDNParamsVCP.h"
#include <stdarg.h>

#ifdef WINDOWS
#include <direct.h>
#else
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#endif

FWDNLogger* FWDNLogger::m_pFWDNLogger = NULL;

FWDNLogger* FWDNLogger::GetIns(){
    if (m_pFWDNLogger == NULL) {
      m_pFWDNLogger = new FWDNLogger;
    }
    return m_pFWDNLogger;
}

FWDNLogger::FWDNLogger() :
m_bDebug(false),
m_bSaveLogFile(false),
m_bTimeStamp(false),
m_pLogFile(NULL)
{
	m_startTime = GetClock();
}

FWDNLogger::~FWDNLogger()
{
	if(m_pLogFile != NULL) {
		fclose(m_pLogFile);
	}
}

void FWDNLogger::Message(unsigned int uiMsgType, const char *fmt, ...)
{
	va_list args;
	va_start(args, fmt);
	vprintf(fmt, args);				//Print log

	if(m_bSaveLogFile == true) {	//Save log
		if(m_pLogFile == NULL) {
			m_pLogFile = fopen(m_strlogFilename, "a+");
		}
		vfprintf(m_pLogFile, fmt, args);
		fclose(m_pLogFile);
		m_pLogFile = NULL;
	}

	va_end(args);
}

void FWDNLogger::DebugMessage(unsigned int uiMsgType, const char *fmt, ...)
{
	if(m_bDebug == true) {
		va_list args;
		va_start(args, fmt);
		Message(uiMsgType, fmt, args);
		va_end(args);
	}
}

clock_t FWDNLogger::GetClock()
{
#ifdef WINDOWS
	return clock();
#else
	struct timespec cur;
	clock_gettime(CLOCK_MONOTONIC, &cur);
	clock_t ret;
	ret = cur.tv_nsec / 1000000;	//ms
	ret += cur.tv_sec * 1000;	//sec
	return ret;
#endif
}

void FWDNLogger::PrintElapsedTime(unsigned int uiMsgType)
{
	if(m_bTimeStamp == true) {
		MakeStrElapsedTime();
		Message(uiMsgType, m_strElapsedTime);
	}
}

void FWDNLogger::PrintCurTime()
{
	time_t curTime = time(NULL);
	struct tm* t;
	char buff[100];

	t = localtime(&curTime);

	sprintf(buff, "%02d/%02d/%02d-%02d:%02d:%02d",
		(t->tm_year + 1900) % 100, t->tm_mon + 1, t->tm_mday, t->tm_hour, t->tm_min, t->tm_sec);

	FWDNMessage(FWDN_BLUE_MSG, "%s\n", buff);
}

void FWDNLogger::MakeStrElapsedTime()
{
	clock_t elapsedTime = GetClock() - m_startTime;

	int ms = (elapsedTime % 1000) / 10;	// ms * 10
	int sec = (elapsedTime / 1000) % 60;
	int min = (elapsedTime / 1000 / 60) % 60;
	sprintf(m_strElapsedTime, "[%02d:%02d:%02d]", min, sec, ms);
}

void FWDNLogger::GetCurTimeStr(std::string *pStrTime)
{
	time_t curTime = time(NULL);
	struct tm* t;
	char buff[100];

	t = localtime(&curTime);

	sprintf(buff, "%02d-%02d-%02d-%02d-%02d-%02d",
		(t->tm_year + 1900) % 100, t->tm_mon + 1, t->tm_mday, t->tm_hour, t->tm_min, t->tm_sec);
	*pStrTime = buff;
}

void FWDNLogger::MakeLogFileName()
{
	std::string strTime;

	GetCurTimeStr(&strTime);
	sprintf(m_strlogFilename, "%s%cFWDN_V8_LOG_%s", LOG_FOLDER, FILE_PATH_TOKEN, strTime.c_str());
}

void FWDNLogger::MakeFolder(const char* pFolderNmae)
{
#ifdef WINDOWS
	mkdir(pFolderNmae);
#else
	mkdir(pFolderNmae, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
#endif
}

void FWDNLogger::SetSaveLog(bool bSaveLog)
{
	m_bSaveLogFile = bSaveLog;
	if(m_bSaveLogFile == true && m_pLogFile == NULL) {
		MakeLogFileName();
		MakeFolder(LOG_FOLDER);
		m_pLogFile = fopen(m_strlogFilename, "wb");
	} else if(m_bSaveLogFile == false && m_pLogFile != NULL) {
		fclose(m_pLogFile);
		m_pLogFile = NULL;
	}
}
