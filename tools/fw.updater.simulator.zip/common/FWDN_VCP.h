#pragma once

#include "../windows/SerialPort.h"
#include "FWDNLogger.h"
#include "FWDNFile.h"
#include "FWDNUtil.h"
#include "protocol/ProtocolCB.h"
#include "protocol/ProtocolFW.h"
#include "FWDNStorage.h"

class FWDN_VCP {
public:
	FWDN_VCP(CSerialPort *serial);

// Chipboot
	bool LoadFwdnFW(FWDNArgs *pFwdnArgs);

// Common(Chipboot + BL1 F/W)
	bool WriteFile(FWDNArgs *pFwdnArgs, unsigned int uiCmd, FwdnProtocol *protocol, unsigned long long ullFileAddr);
	bool WriteFileByBank(FWDNArgs *pFwdnArgs, unsigned int uiCmd, FwdnProtocol *pProtocol);

// BL1 F/W
	bool CheckPing();
	bool InfoStorage();
	bool GetChipInfo();
    bool ReadyToUpdate();
	bool GetDeviceVersion();
	bool DumpStorage(FWDNArgs *pFwdnArgs, unsigned int uiCmd, unsigned int uiRequestSize, char *strFileOption);
	bool DumpStorageByBank(FWDNArgs *pFwdnArgs, unsigned int uiCmd, FwdnProtocol *pProtocol);
	bool LowformatCommand();

	void PrintStorageOption(FWDNArgs &fwdnArgs);
	void PrintBankInfo(FWDNArgs &fwdnArgs, vcp_bank_info &bankInfo);

private:
	CSerialPort *m_serial;
	vcp_chip_info m_vcpChipInfo;
    vcp_bank_info m_vcpBankInfo;
};
