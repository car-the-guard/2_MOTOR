#pragma once

#include "../common/config.h"

//#include <windows.h>
//#include <dbt.h>
#include "../common/IUSBDriver.h"
#include "SerialPort.h"

class FWDNWindowsUART : public IUSBDriver{
private:
    unsigned int m_uiVID;
    unsigned int m_uiPID;
	CSerialPort *m_pSerial;

public:
    FWDNWindowsUART();
    ~FWDNWindowsUART();

    virtual bool OpenPort();
    virtual bool ClosePort();

    virtual bool SendData(char *pBuf, unsigned int size, unsigned int *nBytes = NULL);
    virtual bool ReadData(char *pBuf, unsigned int size, unsigned int *nBytes = NULL);
    virtual unsigned int SetTimeout(unsigned int rwTimeout);

    virtual bool InitUsbNotification();
    virtual void WaitUntilUsbConnected();
    virtual unsigned int GetPID();

	unsigned int SetSerial(CSerialPort *serial);
};
