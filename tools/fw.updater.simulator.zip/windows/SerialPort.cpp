#include "SerialPort.h"
#include "../common/FWDNLogger.h"

CSerialPort::CSerialPort() :
m_hComm(NULL)
{
}

CSerialPort::~CSerialPort()
{
}

bool CSerialPort::OpenPort(char *pPortName, unsigned int uiRwMode)
{
	if(uiRwMode == 0) {
		uiRwMode = GENERIC_READ | GENERIC_WRITE;
	}

	m_hComm = CreateFile(pPortName,		//name
						 uiRwMode,		//read-write mode
						 0,				//share mode
						 0,				//security
						 OPEN_EXISTING,	//create method
						 0,				//flags, attributes
						 0);			//template file

	PurgeComm(m_hComm,
		PURGE_TXABORT | PURGE_RXABORT |  PURGE_TXCLEAR | PURGE_RXCLEAR);

	if (m_hComm == INVALID_HANDLE_VALUE) {
		FWDNMessage(FWDN_RED_MSG, "Failed open port(%s)\n", pPortName);
		m_hComm = NULL;
		return false;
	} else {
		FWDNMessage(FWDN_WHITE_MSG, "Complete open port(%s)\n", pPortName);
		return true;
	}
}

bool CSerialPort::ConfigurePort(
	unsigned long BaudRate, unsigned char ByteSize, unsigned long fParity,
	unsigned char Parity, unsigned char StopBits)
{
	unsigned int err;

	if ((m_hComm == INVALID_HANDLE_VALUE) || (m_hComm == NULL)) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] m_hComm == NULL || m_hComm == INVALID_HANDLE_VALUE\n");
		return false;
	}

	m_bPortReady = GetCommState(m_hComm, &m_dcb) == TRUE ? true : false;
	if (m_bPortReady == FALSE) {
		err = GetLastError();
		FWDNMessage(FWDN_RED_MSG, "GetLastError : %d\n", err);
		FWDNMessage(FWDN_RED_MSG, "Failed GetCommState\n");
		CloseHandle(m_hComm);
		return false;
	}

	m_dcb.BaudRate = BaudRate;
	m_dcb.ByteSize = ByteSize;
	m_dcb.Parity = Parity;
	m_dcb.StopBits = StopBits;
	m_dcb.fBinary = true;
	m_dcb.fDsrSensitivity = false;
	m_dcb.fParity = fParity;
	m_dcb.fOutX = false;
	m_dcb.fInX = false;
	m_dcb.fNull = false;
	m_dcb.fAbortOnError = true;
	m_dcb.fOutxCtsFlow = false;
	m_dcb.fOutxDsrFlow = false;
	m_dcb.fDtrControl = DTR_CONTROL_DISABLE;
	m_dcb.fDsrSensitivity = false;
	m_dcb.fRtsControl = RTS_CONTROL_DISABLE;
	m_dcb.fOutxCtsFlow = false;
	m_dcb.fOutxCtsFlow = false;

	m_bPortReady = SetCommState(
		m_hComm, &m_dcb) == TRUE ? true : false;

	if (m_bPortReady == 0) {
		err = GetLastError();
		FWDNMessage(FWDN_RED_MSG, "GetLastError : %d\n", err);
		FWDNMessage(FWDN_RED_MSG, "Failed SetCommState\n");
		CloseHandle(m_hComm);
		return false;
	}

	return true;
}

bool CSerialPort::SetCommunicationTimeouts(
	unsigned long ReadIntervalTimeout,
	unsigned long ReadTotalTimeoutMultiplier,
	unsigned long ReadTotalTimeoutConstant,
	unsigned long WriteTotalTimeoutMultiplier,
	unsigned long WriteTotalTimeoutConstant)
{
	if ((m_hComm == INVALID_HANDLE_VALUE)
		|| (m_hComm == NULL)) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] m_hComm == NULL || m_hComm == INVALID_HANDLE_VALUE\n");
		return false;
	}

	m_bPortReady = GetCommTimeouts(
		m_hComm, &m_commTimeouts) == TRUE ? true : false;
	if (m_bPortReady == false) {
		return false;
	}

	m_commTimeouts.ReadIntervalTimeout = ReadIntervalTimeout;
	m_commTimeouts.ReadTotalTimeoutConstant = ReadTotalTimeoutConstant;
	m_commTimeouts.ReadTotalTimeoutMultiplier = ReadTotalTimeoutMultiplier;
	m_commTimeouts.WriteTotalTimeoutConstant = WriteTotalTimeoutConstant;
	m_commTimeouts.WriteTotalTimeoutMultiplier = WriteTotalTimeoutMultiplier;

	m_bPortReady = SetCommTimeouts(
		m_hComm, &m_commTimeouts) == TRUE ? true : false;

	if (m_bPortReady == 0) {
		unsigned int err = GetLastError();

		FWDNMessage(FWDN_RED_MSG, "GetLastError : %d\n", err);
		FWDNMessage(FWDN_RED_MSG, "Failed SetCommTimeouts\n");
		CloseHandle(m_hComm);
		return false;
	}

	return true;
}

bool CSerialPort::SendData(
	void *pBuf, unsigned long ulReqSize, unsigned long* pulSendSize)
{
	COMSTAT comstat;
	unsigned long ulErrorFlags;
	bool ret;

	if ((m_hComm == INVALID_HANDLE_VALUE)
		|| (m_hComm == NULL)) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] m_hComm == NULL || m_hComm == INVALID_HANDLE_VALUE\n");
		return false;
	}

	if (pulSendSize == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] ulReadSize == NULL\n");
		return false;
	}
	
	ret = WriteFile(m_hComm, pBuf, ulReqSize,
		(LPDWORD)pulSendSize, NULL) == TRUE ? true : false;

	if (ret == TRUE) {
		//DEBUG_FWDNMessage(FWDN_WHITE_MSG,
		//	"Complete send data\n");
	} else {
		unsigned int err = GetLastError();

		FWDNMessage(FWDN_RED_MSG,
			"GetLastError : %d\n", err);
		FWDNMessage(FWDN_RED_MSG,
			"Failed send data(%lu / %lu)\n",
			*pulSendSize, ulReqSize);
		if (err == 995) {
			ClearCommError(m_hComm, &ulErrorFlags, &comstat);
		}
	}

	return ret;
}

bool CSerialPort::ReadTreshData(unsigned long ulReqSize)
{
	COMSTAT comstat;
	unsigned long ulErrorFlags;
	unsigned long ulRead = 0;
	unsigned long ulReadSize;
	bool ret;

	if ((m_hComm == INVALID_HANDLE_VALUE)
		|| (m_hComm == NULL)) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] m_hComm == NULL || m_hComm == INVALID_HANDLE_VALUE\n");
		return false;
	}

	for (unsigned long i = 0; i < ulReqSize; i++) {
		ClearCommError(m_hComm, &ulErrorFlags, &comstat);
		ulRead = comstat.cbInQue;

		//for debugging test
		char cRecv;
		ulReadSize = 0;
		ret = ReadFile(m_hComm, &cRecv, 1, &ulReadSize, 0) == TRUE ? true : false;
		if (ulReadSize > 0) {
			putchar(cRecv);
		}
	}

	return ret;
}

bool CSerialPort::ReadData(
	void *pBuf, unsigned long ulReqSize, unsigned long* ulReadSize)
{
	bool ret = ReadDataTimeout(pBuf, ulReqSize, ulReadSize, 0);

	return ret;
}

bool CSerialPort::ReadDataTimeout(
	void *pBuf, unsigned long ulReqSize,
	unsigned long* ulReadSize, unsigned int uiTimeout)
{
	COMSTAT comstat;
	unsigned long ulErrorFlags;
	unsigned long ulRead = 0;
	bool ret;

	if ((m_hComm == INVALID_HANDLE_VALUE)
		|| (m_hComm == NULL)) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] m_hComm == NULL || m_hComm == INVALID_HANDLE_VALUE\n");
		return false;
	}

	if (ulReadSize == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] ulReadSize == NULL\n");
		return false;
	}

	if (pBuf == NULL) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] pBuf == NULL\n");
		return false;
	}

	while (ulRead == 0) {
		ClearCommError(m_hComm, &ulErrorFlags, &comstat);
		ulRead = comstat.cbInQue;

		if (uiTimeout > 0) {
			Sleep(1);
			uiTimeout--;
			if(uiTimeout == 0) {
				break;
			}
		}
	}

	*ulReadSize = 0;
	ret = ReadFile(m_hComm, pBuf, ulReqSize, ulReadSize, 0) == TRUE ? true : false;
	if (ret == TRUE) {
		//DEBUG_FWDNMessage(FWDN_WHITE_MSG,
		//	"Complete read data\n");
	} else {
		unsigned int err = GetLastError();

		FWDNMessage(FWDN_RED_MSG,
			"GetLastError : %d\n", err);
		FWDNMessage(FWDN_RED_MSG,
			"Failed read data(%lu / %lu)\n",
			*ulReadSize, ulReqSize);
		if (err == 995) {
			ClearCommError(m_hComm, &ulErrorFlags, &comstat);
		}
	}

	return ret;
}

bool CSerialPort::ReadData(unsigned char data)
{
	unsigned long ulBytesTransferred = 0;
	BOOL ret;

	if ((m_hComm == INVALID_HANDLE_VALUE)
		|| (m_hComm == NULL)) {
		FWDNMessage(FWDN_RED_MSG,
			"[ERROR] m_hComm == NULL || m_hComm == INVALID_HANDLE_VALUE\n");
		return false;
	}

	ret = ReadFile(m_hComm, &data, 1, &ulBytesTransferred, 0);
	if (ret == TRUE) {
		if (ulBytesTransferred == 1) {
			return true;
		}
	}

	return false;
}

void CSerialPort::ClosePort()
{
	if ((m_hComm != INVALID_HANDLE_VALUE)
		&& (m_hComm != NULL)) {
		CloseHandle(m_hComm);
		m_hComm = NULL;
	}
}