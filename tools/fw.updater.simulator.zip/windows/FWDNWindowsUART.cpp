#include "FWDNWindowsUART.h"


FWDNWindowsUART::FWDNWindowsUART()
{
	m_pSerial = NULL;
}

FWDNWindowsUART::~FWDNWindowsUART()
{
}

bool FWDNWindowsUART::OpenPort()
{
	return true;
}

bool FWDNWindowsUART::ClosePort()
{
	return true;
}

bool FWDNWindowsUART::SendData(char *pBuf, unsigned int size, unsigned int *nBytes)
{
	unsigned long sentSize = 0U;

	for (unsigned int remainSize = size; remainSize > 0U;) {
		m_pSerial->SendData(pBuf, remainSize, &sentSize);
		remainSize -= sentSize;
	}

	return true;
}

bool FWDNWindowsUART::ReadData(char *pBuf, unsigned int size, unsigned int *nBytes)
{
	unsigned long receivedSize = 0U;

	for (unsigned int remainSize = size; remainSize > 0U;) {
		m_pSerial->ReadData(pBuf, remainSize, &receivedSize);
		remainSize -= receivedSize;
	}

	return true;
}

unsigned int FWDNWindowsUART::SetTimeout(unsigned int rwTimeout)
{
	return 0U;
}

bool FWDNWindowsUART::InitUsbNotification()
{
	return true;
}

void FWDNWindowsUART::WaitUntilUsbConnected()
{
	//empty
}

unsigned int FWDNWindowsUART::SetSerial(CSerialPort *serial)
{
	m_pSerial = serial;
	return 0;
}


unsigned int FWDNWindowsUART::GetPID()
{
	return 0;
}