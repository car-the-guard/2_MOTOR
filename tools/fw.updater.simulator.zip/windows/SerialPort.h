#pragma once

#include <Windows.h>

class CSerialPort {
public:
	CSerialPort(void);
	virtual ~CSerialPort(void);

private:
	HANDLE m_hComm;
	DCB m_dcb;
	COMMTIMEOUTS m_commTimeouts;

	bool m_bPortReady;
	bool m_bWriteRC;
	bool m_bReadRC;
	unsigned long m_iBytesWritten;
	unsigned long m_iBytesRead;
	unsigned long m_dwBytesRead;

public:
	bool OpenPort(char *pPortName,  unsigned int uiRwMode = 0UL);
	void ClosePort();
	bool ReadData(unsigned char data);
	bool ReadData(void *pBuf, unsigned long ulReqSize, unsigned long* ulReadSize);
	bool ReadDataTimeout(void *pBuf, unsigned long ulReqSize, unsigned long* ulReadSize, unsigned int timeout = 0);
	bool SendData(void *pBuf, unsigned long ulSize, unsigned long* ulSendSize);
	bool SetCommunicationTimeouts(unsigned long ReadIntervalTimeout,
								unsigned long ReadTotalTimeoutMultiplier,
								unsigned long ReadTotalTimeoutConstant,
								unsigned long WriteTotalTimeoutMultiplier,
								unsigned long WriteTotalTimeoutConstant);
	bool ConfigurePort(unsigned long BaudRate, unsigned char ByteSize, unsigned long fParity,
					   unsigned char Parity, unsigned char StopBits);
	bool ReadTreshData(unsigned long ulReqSize);
};
